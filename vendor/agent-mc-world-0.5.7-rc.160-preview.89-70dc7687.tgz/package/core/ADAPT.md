<!-- Owner: src/worlds/minecraft/mineflayer-fixes.ts -->

# 版本适配

Minecraft 服务端换一个版本,客户端这边要跟着改的事实记在这里:版本边界、认得出它的
判据、改在哪、当时怎么量出来的。

**接到「她走不动 / 动作被打回 / 某个动作忽然失效」这类报告,先读这一页。** 这类症状里
客户端看得见的只有"位置包被打回",光读代码分不出是判据变了还是别的;下面每条都带着
当时的实测数字,对得上就直接按那条走。

## 1.21.11:包围盒贴着方块侧面的位置被拒,静默传送回

**版本边界** Paper 1.21.8、1.21.9、1.21.10 收下贴面位置,1.21.11 拒。不带任何插件的
原版 Paper 即可复现,与服务端分支(Leaves)、反作弊插件无关。

**服务端的判据** 把玩家包围盒摆在离方块侧面缝隙 `g` 处发过去:

| `g` | 服务端 |
|---|---|
| > 0(1e-7 也算) | 收下 |
| = 0 或 < 0 | 回一个 `position` 包把人传回上一个好位置,**不打 `moved wrongly`** |

竖直方向的判据不同:贴着地面顶面、贴着天花板底面都照收,只有真的插进去才被拒。

**客户端为什么总是踩中** `prismarine-physics` 的 `AABB.computeOffsetX/Z` 把移动量削到
"恰好贴上"。于是走到墙根、沿墙走、上一格台阶时贴着立面起跳,发出去的位置包缝隙恰好
为零,每个物理刻都被打回,人钉在原地。

**认得出它的样子**

- 服务端日志干净:同时段别的玩家有 `moved wrongly`,bot 一条都没有
- 每秒 1 到 9 个服务端 `position` 包,落点比当前位置略微靠后
- 单次被放行的净位移 0.02 到 0.03 格
- `goto-stall-probe` 里 `onGround=false`、三轴速度为零、y 停在起跳弧线中途的值
  (贴墙起跳第一刻被收、第二刻被打回第一刻的位置),`controlKeys` 显示前进键一直按着

**改法** `mineflayer-fixes.ts` 的 `installWallGap()`:替换 `prismarine-physics` AABB 原型上的
`computeOffsetX` 与 `computeOffsetZ`,朝方块走的那一步停在离面 `WALL_GAP`(1e-5)处,已经
贴着再往里走时退开同样距离;`computeOffsetY` 不动。bot 的物理与寻路器的判据模拟共用
这一个类,改原型两处同时生效。原型上打 `Symbol.for` 标记,装几次都只改一次。

**试过没用的**

- 补上原版客户端 1.21.2+ 每刻发的 `tick_end`、按键变化时的 `player_input`、位置包里真实的
  `hasHorizontalCollision`:三样一起上,打回次数不变
- 压掉 mineflayer 收到传送后回的那个位置包、补发 `player_loaded`:与这条无关

**验证** 不带插件的 Paper 1.21.11,八种一格台阶几何(斜角单块、正对与斜对高台、贴脸
起步、头顶树冠):改前每场被打回 160 到 334 次、两场钉死;改后 16 场全部到达、打回
零次,耗时与 1.20.6 同一量级。

## 怎么量一条新的版本差异

服务端改了移动判据时,别读反编译猜,直接问服务端:

1. 取各版本的原版服务端 jar(Paper 的 `fill.papermc.io/v3/projects/paper/versions/<版本>/builds`),
   一个版本一个进程,端口与存档都隔离。
2. 关掉客户端物理(`bot.physicsEnabled = false`),手工写 `bot.entity.position` 把人摆到要
   测的位置,数 400 毫秒内收到几个服务端 `position` 包。零个 = 服务端认,一个及以上 = 被拒。
3. 缝隙按 0.05、1e-3、1e-5、1e-7、0、负值扫一遍;地面与空中各扫一次;水平与竖直分开扫
   ——两个方向的判据可以不一样,1.21.11 就不一样。
4. 同一套摆法在相邻版本上各跑一次,边界就出来了。

台架在 `scratch/mc-bench/`(不入库):`rig.ts` 起真服务端配真执行器,`BENCH_JAR` 选服务端
jar、`BENCH_VERSION` 选协议版本。


## 26.1: AuthMe 预登录对话框、窗口标题 NBT、无 open_window 的 GUI

**版本边界** 官方 mineflayer 4.39.0 的 `testedVersions` 含 `26.1`（协议 775）。4.37.1 没有这条协议。不改服务端。

**进服卡点** 配置阶段 `show_dialog`（`authme:prejoin-login/submit`），不是先靠聊天 `/login`。`custom_click_action` 必须按 1.21.6+ 原版写成 VarInt 长度前缀 + 匿名 NBT；minecraft-data 仍把该字段标成带有无标志位的 `option anonymousNbt`，按库默认写法提交会被忽略。不要对这个对话框发 `accept_code_of_conduct`。

**窗口标题** `open_window.windowTitle` 是匿名 NBT，直接 `toString()` 会得到 `[object Object]`。在 mineflayer 入库前解包。

**隐藏 GUI** 有的插件只发 `window_items`、不发 `open_window`。mineflayer 关不掉这个窗口，之后指令会报「打开界面时无法执行指令」。在宽限期（默认 200ms）内等不到 `open_window` 就按 window id 发 `close_window`。村民窗那种「先 items 后 open」仍给宽限期，不会误关。

**出生点** 领地出生点可能无提示地把位置拽回去。进服后默认先站着，等首个 play 位置稳定约 1.5 秒再允许闲逛；宿主显式移动不拦截。

**DNS** 部分环境会把域名解析到 `198.18.0.0/15`。默认回退公共 DNS，连解析到的 IP，并把原域名作为 `fakeHost` 做握手。不写死某个服的 IP。
