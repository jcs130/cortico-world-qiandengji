/**
 * 战斗模式 · 档 1(常驻夜间自保)。
 *
 * 战术核 = 台架 v7(scratch/mc-bench/combat/,七轮 300+ 场:30 只僵尸清场、
 * survive 补波 20 场零死亡),旋钮按「自保」配:被打或 3 格内有敌对才动手,
 * 不主动招惹;血线 10 撤;追击 6 格;硬时长 30s;间距 2.6(故意不用台架的 2.88——
 * 2.88 几乎无敌,画面上"站在三十只僵尸中间毫发无伤"比冷却完美更不像人,
 * 2.6 会偶尔挨打,是"人味"旋钮,不是性能旋钮)。
 *
 * 默认自保控制(依据在 RESULTS.md / RESULTS2.md):
 * 1. 没有显式目标时，打最近的 + 1.3 倍粘性。已受理的显式目标在同一可见实体仍有效时保持，失效后恢复默认选择。
 * 2. 贴身 ≥2 只切横扫,否则暴击;冷却一律等满(≥84.8% 才有暴击/横扫/冲刺击退)。
 * 3. 距离用「眼睛 → AABB 最近点」,上限 3.0(服务端判定),不是脚底距离。
 * 4. 移动走上下文图(combat-context.ts):行为只往 interest/danger 图写,硬约束走
 *    masking。不要写成 if/else 模式机——台架前四轮每加一条战术就打断另一条,
 *    根因是架构不是战术。
 * 5. 接近卡住 1.5s 交给寻路器,够得着(≤3.2)立刻收回来自己打。
 * 6. 前摇排进冷却窗口(prep):单独值 1.6×。
 * 7. 亚格间距(spacing):贴上沿做比例控制,目标以 v 逼近就以 v 后退。再值 1.8×。
 * (6+7 合起来把承伤/秒从 0.79 压到 0.27。)
 *
 * 生命周期:夺手不夺嘴——接管移动与出手,事件照常推给人格说话;mc_do 期间
 * 入队不启动;任务队列**挂起**不是抢占,战后从断点续做(非幂等步不重跑)。
 */
import type { Bot } from 'mineflayer';
import { nativeBodyBlockedReason } from './body-readiness.ts';
import { captureDeathTarget, matchesDeathTarget, type DeathTargetIdentity } from './entity-death-identity.ts';
import pathfinderPkg from 'mineflayer-pathfinder';
import { Vec3 } from 'vec3';
import type { Logger } from './support/host-contract.ts';
import type { MinecraftLog } from './log.ts';
import type { SkillCall } from './skills.ts';
import { spatialBody } from './spatial-site.ts';
import type { CombatResult, CombatScene, CombatControlSummary, MovementRejection } from './combat-observation.ts';
import type { DeathLifecycle } from './death-lifecycle.ts';
import {
  HARD, blend, blur, decide, dirSlot, newMap, slotDir, write, writeSlot, type Map16,
} from './combat-context.ts';
import { HOSTILE, bestWeapon, dropOwnedGoal, meleeCooldownMs, releaseBody, setOwnedGoal } from './executor.ts';
import { weaponScore } from './melee.ts';
import { createDefensiveWeaponSelector } from './defensive-weapon.ts';
import { combatLoadout } from './combat-loadout.ts';
import { equipHandConfirmed } from './equipment.ts';
import { walkOnlyPath } from './travel.ts';
import type { FightMode } from './policy.ts';
import { zhEntity, zhName } from './names.ts';
import { zhErrorText } from './receipt.ts';
import { BURNING_BLOCKS, SCORCHING_FLOOR, bodyInWater, canSeeEntity, findBankCell, headInWater } from './terrain.ts';
import { piglinIsHostile } from './piglin.ts';
import { corridorSafe } from './idle-actions.ts';
import { consumeHeldFood } from './skills-craft.ts';
import { SkillBlocked } from './skill-context.ts';
import { itemsInReach } from './inventory.ts';
import { RISKY_FOODS } from './nutrition.ts';
import {
  RANGED_EXIT_RANGE,
  RANGED_ENTER_RANGE,
  inKiteRange,
  type BowEvent,
  type BowShotResult,
  type HybridWeapon,
  type RangedTarget,
} from './ranged.ts';

const { goals } = pathfinderPkg;

/** 眼高;距离全部从这里量 */
const EYE = 1.62;
/** 服务端攻击判定上限(player.entity_interaction_range) */
const REACH_MAX = 3.0;
/** 远程怪贴脸:骷髅 <4 格会后退,逼它的直线预判失效 */
const RANGED_STOP = 1.7;
/** 苦力怕引信触发 3 格,留 0.6 余量 */
const CREEPER_SAFE = 3.6;
/** 贴身几只就改横扫(台架:sweepCrowd 2 全面优于 3) */
const SWEEP_CROWD = 2;
const KB_CROWD = 2;
/** 第二近的怪超过这个距离就当「有空间」,可以暴击 */
const SOLO_SPACE = 6;
/** 间距控制的预判时长:目标以 v 逼近,就按 v·t 提前修正 */
const SPACE_PREDICT_S = 0.25;
/** 接近毫无进展这么久就交给寻路器 */
const STUCK_PATH_MS = 1_500;
/** 战斗诊断只落运行日志，不送进人格上下文。 */
const TRAJECTORY_SAMPLE_MS = 250;
const MOVEMENT_STALL_MS = 1_000;
/** E1:场上没怪之后再等这么久才收工(防"炸完→退出→新怪→再进入"抖动) */
const CLEAR_HOLD_MS = 3_000;
/** E5:连续这么久打不着又靠不近就收工 */
const UNREACHABLE_MS = 6_000;
/**
 * 无实际进展的绝对时限；只有进入近战可达且可见范围或实际命中才重置。
 * 目标移动导致的 reach 差分不重置此计时。
 */
const UNREACHABLE_HARD_MS = 20_000;
/** 进场后刀和箭均未出手的时限；不依赖挥刀次数门槛。 */
const NO_SWING_MS = 15_000;
/** E8:够得着、刀也挥出去了,却这么久一下没打中,就是打不到它 */
const NO_DAMAGE_MS = 6_000;
/** E8 起判所需的挥刀数:刚接敌头两刀还没回音不算 */
const NO_DAMAGE_SWINGS = 3;
/** 战况事件的节流 */
const STATUS_EVERY_MS = 6_000;
/** 击杀事件合并窗口 */
const KILL_MERGE_MS = 2_000;
/** E4 战斗占比的滑动窗口 */
const BUSY_WINDOW_MS = 300_000;
/**
 * `queue:"now"` 交还身体之后的宽限:这段时间内不自动进场。
 * 没有它,250ms 巡检会在下一拍把刚开跑的那一单重新挂起 —— 交还就白交了。
 */
const STAND_DOWN_GRACE_MS = 5_000;
/** 挥刀到目标掉血的判定窗口(一个网络往返);超窗的掉血算别人打的,不记进命中 */
const LANDED_WINDOW_MS = 400;
/** 撤退:最近威胁超过这个距离,并保持无伤一段时间,才算安全 */
const RETREAT_CLEAR_DIST = 16;
/** 距离安全与无伤都要连续守住这一段,过滤瞬时丢实体/箭还在飞的假脱离 */
const RETREAT_SAFE_HOLD_MS = 1_500;
/** 撤退净位移这么久没有增加,持续受击时就视为逃路已经证伪 */
const RETREAT_STALL_MS = 1_500;
/** 到时只升级策略,不能在威胁仍近时把撤退记成成功 */
const RETREAT_MAX_MS = 8_000;
/** 会话级总上限:连续战斗(含 fight/retreat 振荡)超此时长强制释放,
 * 防"够不着的怪"无限锁执行器(09-29 水面战斗锁事故补闸)。 */
const COMBAT_TOTAL_CAP_MS = 240_000;
/**
 * 撤退中连续未受击的时限；到期且撤退已超时、无进展时交还身体。
 * 再次受击仍由 onHurtBy 重新处理。
 */
const RETREAT_IDLE_MS = 10_000;
/** E5/E8 收工后的主动进场冷却，防止近处不可达目标立即触发新战斗。 */
const STUCK_COOLDOWN_MS = 10_000;

/** 远程怪:该举盾、该贴脸 */
const RANGED = new Set(['skeleton', 'stray', 'bogged', 'pillager', 'witch', 'blaze', 'ghast', 'illusioner', 'breeze']);
const FOOD_RETRY_MS = 5_000;
const OFFHAND_RETRY_MS = 5_000;

/** E7:反射不主动交战;挨打时除 REPORT_ONLY 外一律撤 */
const NO_FIGHT = new Set(['warden', 'wither', 'ender_dragon']);
/**
 * 挨打只报不撤的 NO_FIGHT。末影龙只在末地出现,去末地就是去打它;自动撤退在
 * 主岛上等于朝虚空跑。打不打、怎么打由任务决定(attack 步里挨打本来就由任务吸收)。
 */
const REPORT_ONLY = new Set(['ender_dragon']);

/**
 * 撤退每一拍踩出去之前看前方那一格往下多深有落脚。超过这个深度按悬崖处理:
 * 原版摔落伤害 = 落差 - 3,3 格以内不掉血;末地岛边往下是虚空,整柱都空。
 */
const RETREAT_MAX_DROP = 3;

/** 主动进场高于脱战血线的余量，单位为生命点；普通受击入场不加此余量。 */
const ENGAGE_MARGIN = 3;

/** 主手此刻的读数,空着念「空手」 */
function heldText(bot: Bot): string {
  return bot.heldItem ? zhName(bot.heldItem.name) : '空手';
}

/**
 * 朝 (dx,dz) 迈一步踩得住吗:前方 1.2 格那一柱,从脚那层往下 RETREAT_MAX_DROP 格内有实心(或脚那层
 * 本身是台阶/墙,由 autoJump 跳),且落脚面不是岩浆。区块没加载不拦,那是读不到,不是悬崖。
 */
export function footingAhead(bot: Bot, dx: number, dz: number): boolean {
  const len = Math.hypot(dx, dz);
  if (len < 1e-6) return true;
  const p = bot.entity.position;
  const x = Math.floor(p.x + (dx / len) * 1.2);
  const z = Math.floor(p.z + (dz / len) * 1.2);
  const y = Math.floor(p.y);
  for (let d = 0; d <= RETREAT_MAX_DROP + 1; d++) {
    const b = bot.blockAt(new Vec3(x, y - d, z));
    if (!b) return true;
    if (b.name === 'lava') return false;
    if (b.boundingBox === 'block') return true;
  }
  return false;
}

export interface CombatTuning {
  enabled: boolean;
  /** 服务端明确确认在试炼层内；需要主动清怪才能推进。 */
  arena?: boolean;
  /** 触发半径:这么近才算"找上门",不主动招惹(档 1 没有先手) */
  engageRadius: number;
  /** 追击上限(格) */
  chaseMax: number;
  /** Explicit host-selected pursuit only; does not expand passive auto engagement. */
  decisionRange?: number;
  /** E3 硬时长闸(秒) */
  maxSec: number;
  /** 理想间距。2.88 几乎无敌;2.6 像个会玩的人 */
  space: number;
  /** E4:5 分钟滑窗里战斗占比超过这个百分数就强制冷却 */
  busyRatio: number;
  /** E4 触发后多少秒内不自动进入 */
  cooldownSec: number;
  /** 血线:低于它就收手撤退(与反射的脱战血线同源) */
  fleeHealth: number;
  /**
   * 主动进场的条件(mc_policy 的 `fight`)。只接在 `watchTick` 那一条上:
   * 受击处理与 E1–E9 退出闸独立于此模式。
   */
  fight: FightMode;
}

interface CombatSessionOptions {
  getBot: () => Bot | null;
  tuning: () => CombatTuning;
  /** 环境自保(岩浆/溺水反射/主动传送)正在进行:比战斗优先,期间不进场、进了也让位 */
  envBusy: () => boolean;
  /**
   * 逃生任务持有身体期间，巡检与受击均不另起战斗。
   */
  taskEscaping?: () => boolean;
  /** 已开始的进食占用主手；受击不另起战斗打断消费。 */
  taskEating?: () => boolean;
  /** 主动 attack 已持有身体；被动三格巡检不得把同一场再接管一遍。 */
  taskFighting?: () => boolean;
  /**
   * 夺手:冻结任务执行器(当前任务断点挂起,队列原样保留,新任务只收不跑)。
   * `by` 是记进 `skill/aborted` 日志的抢占方,写清是哪一只怪触发的。
   */
  suspendTasks: (by: string) => void;
  /** 还手:解冻并从断点续做;返回一句"接着做"的说明(没有挂起任务则 null) */
  resumeTasks: () => string | null;
  /**
   * 事件出口。第一人称事实,不出现「战斗模式/脚本/接管」(闭包原则)。
   * hurt=true 表示这句已讲明掉血来由,World 据此不再复述掉血播报。
   */
  emit: (text: string, urgent: boolean, hurt?: boolean) => void;
  /** 进入低血撤退前可尝试不占用身体的服务端防护技能。 */
  onLowHealth?: (bot: Bot) => void;
  /** Observed encounter terminal state, including interruptions; no causal conclusion. */
  report?: (result: CombatResult) => void;
  ranged?: CombatRangedActions;
  diag?: MinecraftLog;
  log: Logger;
}

export interface CombatRangedActions {
  ready(bot: Bot): boolean;
  active(): boolean;
  shoot(target: RangedTarget, ownerToken: unknown): Promise<BowShotResult>;
  abort(): void;
}

interface Foe {
  id: number;
  name: string;
  ent: NonNullable<Bot['entities'][number]>;
  pos: Vec3;
  /** 眼睛到 AABB 最近点——服务端攻击判定用的就是这个 */
  reach: number;
  /** 水平距离,给站位用 */
  flat: number;
  visible: boolean;
}

type EndReason = 'clear' | 'flee' | 'timeout' | 'stuck' | 'mc_stop' | 'env' | 'death' | 'gone' | 'busy' | 'preempt' | 'inhibited';

/** 眼睛到实体 AABB 最近点的距离 */
function aabbReach(bot: Bot, e: { position: Vec3; height?: number; width?: number }): number {
  const eye = bot.entity.position.offset(0, EYE, 0);
  const w = (e.width ?? 0.6) / 2;
  const h = e.height ?? 1.8;
  const cx = Math.max(e.position.x - w, Math.min(eye.x, e.position.x + w));
  const cy = Math.max(e.position.y, Math.min(eye.y, e.position.y + h));
  const cz = Math.max(e.position.z - w, Math.min(eye.z, e.position.z + w));
  return Math.hypot(eye.x - cx, eye.y - cy, eye.z - cz);
}

/** 从某只眼睛看不看得见这只怪(苦力怕引信全程要视线,断视线即熄) */
function hasLosFrom(bot: Bot, eye: Vec3, e: { position: Vec3; height?: number }): boolean {
  try {
    const to = e.position.offset(0, (e.height ?? 1.8) * 0.6, 0);
    const d = to.minus(eye);
    const len = d.norm();
    if (len < 0.5) return true;
    const hit = (bot.world as unknown as {
      raycast(f: Vec3, dir: Vec3, range: number, matcher?: (b: unknown) => boolean): unknown;
    }).raycast(eye, d.scaled(1 / len), len, (b) => Boolean(b) && (b as { boundingBox?: string }).boundingBox === 'block');
    return !hit;
  } catch {
    return true;
  }
}

/**
 * 档 1 战斗会话:触发、v7 战术核、退出闸门、事件面,一个 owner 管到底。
 * 反射层的受击反击与它合并(combat.enabled 时反射不再自己抡),环境自保仍在
 * 它之上(envBusy 让位)。
 */
export class CombatSession {
  private watch: ReturnType<typeof setInterval> | null = null;
  private state: 'idle' | 'fighting' | 'retreating' | 'tracking' = 'idle';
  private trackingLease: { targetId: number; uuid: string | null; minDistance: number; maxDistance: number; expiresAt: number } | null = null;
  private bot: Bot | null = null;
  private releaseWalkOnly: (() => void) | null = null;
  private controlSummary: CombatControlSummary = { schemaVersion: 1, finalMode: 'fighting', enteredDesperate: false, retreat: null };
  private retreatSamplePosition: { x: number; z: number } | null = null;
  private lastMovementRejection: MovementRejection | null = null;
  private startedAt = 0;
  private healthBefore: number | null = null;
  /** A combat observation belongs to this life, never to the next respawn. */
  private lifeEpisodeAtStart: string | null = null;
  private sceneBefore: CombatScene | undefined;
  /** 会话级总_cap 起点:仅 idle→engage 时重置,内部 fight/retreat 振荡不重置 */
  private sessionStartedAt = 0;
  /** 总_cap 触发后的被动再进场冷却;受击自卫(hurt=true)不受此限 */
  private capCooldownUntil = 0;
  private deadlineAt = 0;
  private cooldownUntil = 0;
  private cooldownNoticed = false;
  /** E4 滑窗:每场战斗的 [开始,结束] */
  private readonly busyLog: Array<{ from: number; to: number }> = [];
  /** 打过我们的实体(末影人只有惹过我们才进目标池) */
  private readonly provoked = new Set<number>();
  /** 我们出手打过的:关联目标死亡的观察，不据此认领本人击杀。 */
  private readonly struck = new Map<number, DeathTargetIdentity>();
  /** 死亡事件先于实体表清理；本场已经死亡的实体不得继续参与威胁判断。 */
  private readonly deadIds = new Set<number>();
  private targetDeaths = new Map<string, number>();
  private targetDeathsPending = new Map<string, number>();
  private lastKillEmitAt = 0;
  private lastStatusAt = 0;
  private emptySince = 0;
  private retreatFrom: { x: number; z: number } | null = null;
  private retreatStartedAt = 0;
  private retreatWhy: 'flee' | 'mc_stop' | 'no-fight' = 'flee';
  /** 在水里撤退时的登岸目标;上岸或转身还手后清掉 */
  private retreatBank: { x: number; y: number; z: number } | null = null;
  /** 这一场撤退里挨的打:逃不掉(挨打且怪还贴着)就转身还手的判据 */
  private retreatHits = 0;
  /** 最近一次撤退中受伤；安全结束必须在它之后守住无伤时窗 */
  private retreatLastHurtAt = 0;
  /** 威胁距离首次进入安全区的时刻；重新靠近就清零 */
  private retreatSafeSince = 0;
  /** 撤退净位移最近一次取得进展的时刻与位置 */
  private retreatProgressAt = 0;
  private retreatProgressPos: { x: number; y: number; z: number } | null = null;
  /** 非可战目标/明确收手在超时后继续撤，只记一次策略升级 */
  private retreatEscalated = false;
  /** 空手低血挡下的那次转身还手,一场撤退只记一次(判据每 250ms 都会再成立一遍) */
  private retreatBarehandNoted = false;
  /** 这一场撤退有没有记过「前面没落脚」;一场只记一次 */
  private retreatEdgeNoted = false;
  /** 撤退失败转身还手中:E2 血线对本场静默(血线的前提是"跑得掉",这里已经证伪) */
  private desperate = false;
  private hadCombatWeapon = false;
  private rangedUnavailable = false;
  private rangedBlocked: { firstAt: number; reason: string; cause?: string } | null = null;
  private meleeEquip: { bot: Bot; weapon: string; startedAt: number; failed: boolean } | null = null;

  // —— v7 出手/移动状态
  private lastSwingAt = 0;
  private swingPhase: 'idle' | 'hop' | 'settle' = 'idle';
  private phaseTargetId = -1;
  private phaseUntil = 0;
  private wtapUntil = 0;
  private sprintSince = 0;
  private shieldUp = false;
  private shieldHoldUntil = 0;
  private offhandEquipping = false;
  private lastOffhandAttemptAt = Number.NEGATIVE_INFINITY;
  private eating = false;
  private supplyGeneration = 0;
  private lastFoodAttemptAt = Number.NEGATIVE_INFINITY;
  private lastSelfHurtAt = Number.NEGATIVE_INFINITY;
  private targetId = -1;
  private selectedTarget: { id: number; uuid: string | null; entity: Bot['entity'] } | null = null;
  private pathing = false;
  private pathUntil = 0;
  private lastReach = 99;
  private lastProgressAt = 0;
  /** 上一次**真**进展(够得着+视线,或走到跟前)的时刻;reach 差分刷新不了这条 */
  private lastRealProgressAt = 0;
  private lastLandedAt = 0;
  private readonly ctxI: Map16 = newMap();
  private readonly ctxD: Map16 = newMap();
  private readonly ctxPrevI: Map16 = newMap();
  private readonly ctxPrevD: Map16 = newMap();
  private readonly ctxTerrain: Map16 = newMap();
  private ctxTerrainAt = 0;
  private readonly ctxCreeper: Map16 = newMap();
  private ctxCreeperAt = 0;
  private coverCell: { x: number; y: number; z: number } | null = null;
  private coverAt = 0;
  private trajectoryAt = 0;
  private trajectoryPos: { x: number; y: number; z: number } | null = null;
  private movementIntent: { x: number; z: number } | null = null;
  private tacticalMove: { origin: Vec3; destination: Vec3; expiresAtMs: number } | null = null;
  private stallSince = 0;
  private stallMode = '';
  private pathRetryAfter = 0;
  private readonly blockedHeadings: Array<{ x: number; z: number; until: number }> = [];

  /**
   * 出手记账:挥了几次、其中几次让目标掉了血。`bot.attack()` 只管发包,够不够得着
   * 由服务端说了算 —— 不分账的话「打了半天没打死」在日志上与「压根没碰到」同形。
   */
  private swings = 0;
  private landed = 0;
  private lastSwingTargetId = -1;
  private hybridWeapon: HybridWeapon = 'melee';
  private readonly selectDefensiveWeapon = createDefensiveWeaponSelector();
  private rangedOwner: object | null = null;
  private rangedPendingOwner: object | null = null;
  private nextRangedAt = 0;
  private arrows = 0;
  private rangedLanded = 0;
  private lastRangedHitTargetId = -1;
  private lastRangedHitAt = 0;

  private readonly onTick = (): void => {
    if (this.bot && !this.bodyEnded(this.bot)) this.sampleTrajectory();
    this.tick();
  };
  private readonly onDead = (e: { id?: number; name?: string; position?: Vec3 }): void => this.noteDead(e);
  private readonly onFoeHurt = (e: { id?: number }, source?: { id?: number }): void => this.noteFoeHurt(e, source);
  private readonly onSelfDeath = (): void => {
    if (this.state !== 'idle') this.end('death');
    else this.cancelRanged();
  };

  constructor(private readonly opts: CombatSessionOptions) {}

  start(): void {
    if (this.watch) return;
    this.watch = setInterval(() => this.watchTick(), 250);
    this.watch.unref?.();
  }

  stop(): void {
    if (this.watch) clearInterval(this.watch);
    this.watch = null;
    if (this.state !== 'idle') this.end('gone');
    else this.cancelRanged();
  }

  /** 正在打(或正在撤)。执行器的受理回执与 World 的播报口径都看它 */
  get active(): boolean {
    return this.state !== 'idle';
  }

  /** 只在实际交战时允许进攻法术；撤退和 mc_stop 不主动施放。 */
  get fighting(): boolean {
    return this.state === 'fighting';
  }
  get tracking(): boolean { return this.state === 'tracking'; }

  reactionState(): { targetId: number | null; canStep: boolean; sinceHitMs: number | null; retreating: boolean } {
    if (!this.bot || !this.alive(this.bot) || this.bodyEnded(this.bot))
      return { targetId: null, canStep: false, sinceHitMs: null, retreating: false };
    return { targetId: this.targetId >= 0 ? this.targetId : null,
      canStep: this.fighting && !this.eating && !this.pathing && this.swingPhase === 'idle' && this.hybridWeapon === 'melee',
      sinceHitMs: this.fighting ? Date.now() - Math.max(this.lastLandedAt, this.startedAt) : null,
      retreating: this.state === 'retreating' };
  }

  /** Read-only target eligibility shared by candidate construction and execution. */
  engagementTargets(): number[] {
    const bot = this.opts.getBot(), t = this.opts.tuning();
    if (!this.alive(bot) || (this.active && (this.bodyEnded(bot) || (!this.tracking && !this.fighting))) || !t.enabled || t.fight === 'off'
      || this.opts.envBusy() || this.opts.taskEscaping?.() || this.opts.taskFighting?.()
      || (bot.health ?? 0) < t.fleeHealth + ENGAGE_MARGIN
      || (t.fight === 'armed' && !bestWeapon(bot) && !this.rangedReady(bot))
      || Date.now() < this.capCooldownUntil
      || (!t.arena && Date.now() < this.cooldownUntil)
      || (!t.arena && this.busyRatioNow() > t.busyRatio / 100)) return [];
    // Match the actual controller's usable ranged pool. Previously a loaded bow
    // could shoot these targets after injury, but the chooser could only wait
    // or retreat when the same visible targets were outside melee pursuit.
    const range = Math.max(t.chaseMax + 4, Math.min(32, Math.max(0, t.decisionRange ?? 0)),
      this.rangedReady(bot) ? RANGED_ENTER_RANGE : 0);
    return this.scan(bot, t, range).filter(f => f.visible && !NO_FIGHT.has(f.name)).map(f => f.id);
  }

  /** Tracking must use the same provocation, visibility and admission rules as react(). */
  trackingTargets(): number[] {
    const bot = this.opts.getBot(), t = this.opts.tuning();
    if (!this.alive(bot) || (this.active && this.bodyEnded(bot)) || !t.enabled || this.state === 'retreating'
      || this.opts.envBusy() || this.opts.taskEscaping?.() || this.opts.taskFighting?.()
      || (bot.health ?? 0) < t.fleeHealth + ENGAGE_MARGIN
      || (!this.active && (Date.now() < this.capCooldownUntil
        || (!t.arena && this.busyRatioNow() > t.busyRatio / 100)))) return [];
    // Observation does not require a weapon or permission to start attacking.
    return this.scan(bot, t, 24).filter(f => f.visible).map(f => f.id);
  }

  canRetreat(): boolean {
    const bot = this.opts.getBot();
    if (!this.alive(bot) || (this.active && this.bodyEnded(bot)) || this.opts.envBusy()
      || this.opts.taskEscaping?.() || this.opts.taskFighting?.()) return false;
    return this.active || this.scan(bot, this.opts.tuning(), RETREAT_CLEAR_DIST).some(f => f.visible);
  }

  /** Reuses the combat body's existing lease, health gates and retreat controller. */
  react(action: { kind: 'engage'; targetId: number } | { kind: 'retreat' }
    | { kind: 'track'; targetId: number; uuid: string | null; minDistance: number; maxDistance: number; leaseMs: number }
    | { kind: 'step'; destination: [number, number, number] }): boolean {
    const bot = this.opts.getBot();
    if (!this.alive(bot) || (this.active && this.bodyEnded(bot)) || this.opts.envBusy() || this.opts.taskEscaping?.() || this.opts.taskFighting?.()) return false;
    if (action.kind === 'retreat') {
      if (!this.canRetreat()) return false;
      if (this.state === 'retreating') return true;
      if (!this.active) {
        this.bot = bot; this.opts.suspendTasks('快决策:交战前撤离'); this.hook(bot);
      }
      this.trackingLease = null;
      this.tacticalMove = null; this.beginRetreat('flee'); return true;
    }
    if (action.kind === 'track') {
      if (!this.trackingTargets().includes(action.targetId)) return false;
      const foe = this.scan(bot, this.opts.tuning(), 24).find(f => f.id === action.targetId && f.visible);
      if (!foe || action.uuid !== (bot.entities[action.targetId]?.uuid ?? null)
        || !Number.isFinite(action.minDistance) || !Number.isFinite(action.maxDistance)
        || action.minDistance < 3.5 || action.maxDistance < action.minDistance + 1 || action.maxDistance > 16
        || !Number.isFinite(action.leaseMs) || action.leaseMs < 500 || action.leaseMs > 6000
        || this.state === 'retreating') return false;
      if (!this.active && !this.engage(foe.name, false, 'tracking')) return false;
      if (this.reactionState().retreating) return false;
      if (this.trackingLease?.targetId === action.targetId && this.trackingLease.uuid === action.uuid) {
        this.trackingLease = { ...action, expiresAt: Date.now() + action.leaseMs }; return true;
      }
      this.cancelRanged(); this.cancelCombatFood(bot); this.release(bot);
      if (this.pathing) dropOwnedGoal(bot, 'combat', '保持距离', this.opts.diag);
      this.pathing = false; this.swingPhase = 'idle'; this.state = 'tracking'; this.targetId = action.targetId;
      this.trackingLease = { ...action, expiresAt: Date.now() + action.leaseMs };
      return true;
    }
    if (action.kind === 'step') {
      const to = new Vec3(...action.destination);
      if (!this.reactionState().canStep || !corridorSafe(bot, bot.entity.position, to)) return false;
      this.tacticalMove = { origin: bot.entity.position.clone(), destination: to, expiresAtMs: Date.now() + 700 };
      return true;
    }
    const foe = bot.entities[action.targetId];
    if (!foe || !this.engagementTargets().includes(action.targetId) || combatLoadout(bot).canEngage !== true) return false;
    if (this.tracking) {
      this.trackingLease = null; this.state = 'fighting'; this.rangedOwner = {};
      this.hybridWeapon = this.selectDefensiveWeapon({phase:'start',current:this.hybridWeapon,heldItem:bot.heldItem?.name??null,
        rangedReady:this.rangedReady(bot),meleeReady:Boolean(bestWeapon(bot)),distance:null});
      if(this.hybridWeapon==='melee')this.armMelee(bot);
      this.lastLandedAt = this.lastProgressAt = this.lastRealProgressAt = Date.now();
    } else if (!this.fighting && !this.engage(foe.name ?? '', false)) return false;
    if (this.fighting) {
      if (this.targetId !== action.targetId) {
        this.cancelRanged();
        // Cancellation invalidates the old shot lease, not the entire new
        // fight. Without a fresh owner, tryRanged silently returned forever
        // after every fast-decision engagement (including idle -> engage).
        this.rangedOwner = {};
        this.tacticalMove = null;
        if (this.pathing) dropOwnedGoal(bot, 'combat', '切换已选择目标', this.opts.diag);
        this.pathing = false; this.release(bot);
      }
      this.targetId = action.targetId;
      this.selectedTarget = { id: action.targetId, uuid: foe.uuid ?? null, entity: foe };
    }
    return true;
  }

  /** 这只怪的死由战斗会话来说,World 的「它死了」播报让位 */
  claims(id: number): boolean {
    return this.state !== 'idle' && this.struck.has(id);
  }

  /** 弓控制器的租约只在创建它的这一场战斗内有效。 */
  ownsRanged(ownerToken: unknown): boolean {
    return this.state === 'fighting' && ownerToken === this.rangedOwner;
  }

  /** 近战发包窗口优先，防止在途旧箭把刚落下的一刀归成远程命中。 */
  acceptsRangedHit(targetId: number, at = Date.now()): boolean {
    return this.rangedOwner !== null && !(
      this.lastSwingTargetId === targetId && at - this.lastSwingAt <= LANDED_WINDOW_MS
    );
  }

  onBowEvent(event: BowEvent): void {
    if (event.kind === 'blocked' || !this.ownsRanged(event.ownerToken)) return;
    if (event.kind === 'released') {
      this.arrows += 1;
      this.rangedBlocked = null;
      // A released arrow proves the ranged body can act. Only a hit extends
      // the hard no-damage window; repeated misses must still terminate.
      this.lastProgressAt = event.at;
      this.nextRangedAt = Math.max(this.nextRangedAt, event.at + 200);
      return;
    }
    this.rangedLanded += 1;
    this.landed += 1;
    this.lastLandedAt = event.at;
    this.lastRangedHitTargetId = event.targetId;
    this.lastRangedHitAt = event.at;
    this.rememberStruck(event.targetId);
  }

  onConnectionLost(): void {
    if (this.state !== 'idle') this.end('gone');
    else this.cancelRanged();
  }

  /** An observed inability to act is neither a navigation failure nor a lost battle. */
  inhibit(): void {
    if (this.state !== 'idle') this.end('inhibited');
    else this.cancelRanged();
  }

  /**
   * 反射层受击时转进来。返回 true = 会话或逃生任务处理(反射不再自己抡);
   * false = 会话进不了场(关着/冷却/环境自保中),退回反射的降级行为。
   */
  onHurtBy(attackerId: number, name: string): boolean {
    const t = this.opts.tuning();
    if (!t.enabled) return false;
    const current = this.opts.getBot();
    if (!this.alive(current) || (this.active && this.bodyEnded(current))) {
      if (this.active && current && current === this.bot) this.end(this.bodyEnded(current) ? 'death'
        : nativeBodyBlockedReason(current) ? 'stuck' : 'gone');
      return false;
    }
    this.lastSelfHurtAt = Date.now();
    if (this.state === 'retreating') {
      this.retreatHits += 1;
      this.retreatLastHurtAt = Date.now();
      this.retreatSafeSince = 0;
      this.provoked.add(attackerId);
      return true;
    } // 已经在撤了,别叠加;伤害历史留在同一场里,逃不掉要转身
    if (this.state === 'fighting') {
      this.provoked.add(attackerId);
      if (!this.desperate && this.bot && !bestWeapon(this.bot) && !this.rangedReady(this.bot)) this.retreatUnarmed();
      return true;
    }
    if (this.tracking) {
      this.provoked.add(attackerId); this.trackingLease = null;
      this.beginRetreat('flee'); return true;
    }
    if (this.opts.taskFighting?.()) return true;
    if (this.opts.taskEating?.()) {
      this.provoked.add(attackerId);
      this.opts.diag?.write({ lane: 'combat', event: 'hurt-during-eat',
        msg: '进食仍持有主手，受击未另起战斗', data: { attackerId, name, health: this.opts.getBot()?.health } });
      return true;
    }
    if (this.opts.taskEscaping?.()) {
      this.provoked.add(attackerId);
      const bot = this.opts.getBot();
      if (bot && (bot.health ?? 20) < t.fleeHealth) this.opts.onLowHealth?.(bot);
      this.opts.diag?.write({ lane: 'combat', event: 'hurt-during-escape',
        msg: '逃生任务仍持有身体，受击未另起战斗', data: { attackerId, name, health: bot?.health } });
      return true;
    }
    if (this.opts.envBusy()) return false;
    // 头在水里不接手:水下近战是另一回事,交回 surface/防溺水那条线
    const bot = this.opts.getBot();
    if (bot && headInWater(bot)) return false;
    if (REPORT_ONLY.has(name)) {
      // 不急报:一次俯冲连着打几下,由投递批次合并
      this.opts.emit(`${zhEntity(name)}打中了我(生命 ${this.hp()}/20);它不在自动撤退之列,手上的任务照常`, false, true);
      return false;
    }
    // E7:打不过的,不进场,直接跑
    if (NO_FIGHT.has(name)) {
      this.bot = this.opts.getBot();
      if (!this.bot) return false;
      this.opts.suspendTasks(`战斗:${zhEntity(name)}打不过,撤退`);
      this.hook(this.bot);
      this.opts.emit(`是${zhEntity(name)}!这个打不过,快跑!(生命 ${this.hp()}/20)`, true, true);
      this.beginRetreat('no-fight');
      return true;
    }
    if (bot?.entity && !bestWeapon(bot) && !this.rangedReady(bot)) {
      this.bot = bot;
      this.provoked.add(attackerId);
      this.opts.suspendTasks(`战斗:空手受击,撤退`);
      this.hook(bot);
      this.retreatUnarmed();
      return true;
    }
    // A hit can arrive through a wall or after the attacker leaves the loaded
    // entity table. Starting a fight with no visible target just holds the body
    // for three seconds, then resumes the task into the next hit indefinitely.
    const attacker = bot?.entities[attackerId];
    if (bot && (!attacker?.isValid || !attacker.position || !canSeeEntity(bot, attacker))) {
      this.bot = bot;
      this.provoked.add(attackerId);
      this.opts.suspendTasks(`战斗:被看不见的${zhEntity(name)}打了,撤退`);
      this.hook(bot);
      this.opts.emit(`被${zhEntity(name)}打到了,但隔着障碍看不见它,先撤到安全处。`, true, true);
      this.beginRetreat('flee');
      return true;
    }
    this.provoked.add(attackerId);
    return this.engage(name, true);
  }

  private retreatUnarmed(): void {
    this.opts.emit(`空手,没有可用武器,这架不还手了,先撤。(生命 ${this.hp()}/20)`, true, true);
    this.opts.diag?.write({ lane: 'combat', event: 'barehand-flee',
      msg: '受击或交战中失去可用武器,撤退', data: { health: this.bot?.health } });
    this.beginRetreat('flee');
  }

  /** 250ms 巡检:3 格内有敌对就开打(不主动招惹,这是"找上门"的判据) */
  private watchTick(): void {
    // This wall-clock watcher still runs when physicsTick has stopped. Do not
    // hold the task queue forever or call a stale retreat a successful escape.
    if (this.state !== 'idle' && this.bot && nativeBodyBlockedReason(this.bot)) {
      this.opts.emit('身体位置或物理更新未就绪，这次交战受阻；没有确认撤离成功。', true, false);
      this.end('stuck');
      return;
    }
    if (this.state !== 'idle') return;
    const t = this.opts.tuning();
    // 逃生与主动攻击各自持有身体，巡检不重复接管。
    if (!t.enabled || this.opts.envBusy() || this.opts.taskEscaping?.() || this.opts.taskFighting?.()) return;
    if (t.fight === 'off') return;
    if (!t.arena && Date.now() < this.cooldownUntil) return;
    const bot = this.opts.getBot();
    if (!this.alive(bot)) return;
    // armed 模式仅在背包有可用近战武器或远程武器就绪时主动进场。
    if (t.fight === 'armed' && !bestWeapon(bot) && !this.rangedReady(bot)) return;
    this.bot = bot;
    const foes = this.scan(bot, t);
    const near = foes.find((f) => f.visible && f.reach <= t.engageRadius && !NO_FIGHT.has(f.name));
    if (near) {
      if (near.name === 'piglin') this.provoked.add(near.id);
      this.engage(near.name, false);
    }
  }

  /** 播报用的整数血量:向上取整与游戏 HUD 的半颗心一致,0.1 血活着就报 1,不报 0。判定一律用浮点原值。 */
  private hp(): number {
    return Math.ceil(this.bot?.health ?? 0);
  }

  private life(bot: Bot): DeathLifecycle | undefined {
    return (bot as Bot & { deathLifecycle?: DeathLifecycle }).deathLifecycle;
  }

  private alive(bot: Bot | null | undefined): bot is Bot {
    if (!bot?.entity || !Number.isFinite(bot.health) || bot.health <= 0) return false;
    if (nativeBodyBlockedReason(bot)) return false;
    const phase = this.life(bot)?.phase;
    return phase === undefined || phase === 'alive';
  }

  private bodyEnded(bot: Bot): boolean {
    const life = this.life(bot);
    return (Number.isFinite(bot.health) && bot.health <= 0)
      || (!!life && (life.phase !== 'alive' || life.episodeId !== this.lifeEpisodeAtStart));
  }

  private engage(firstName: string, hurt: boolean, initial: 'fighting' | 'tracking' = 'fighting'): boolean {
    const bot = this.opts.getBot();
    if (!this.alive(bot) || (this.active && this.bodyEnded(bot))) return false;
    // 血线不足时转入撤退，避免 250ms 巡检反复尝试进场。
    const line = this.opts.tuning().fleeHealth + (hurt ? 0 : ENGAGE_MARGIN);
    if ((bot.health ?? 20) < line) {
      this.bot = bot;
      this.opts.suspendTasks(`战斗:血只剩 ${this.hp()},不接这架`);
      this.hook(bot);
      this.opts.emit(`血只剩 ${this.hp()}/20,这架不接了,先拉开。`, true, hurt);
      this.opts.diag?.write({
        lane: 'combat', event: 'engage-refused',
        msg: `血线挡下进场:${firstName}${hurt ? '(挨了打)' : '(进了 3 格圈)'},` +
          `生命 ${this.hp()}/20 低于入场线 ${line}`,
        data: { first: firstName, hurt, health: bot.health, line },
      });
      this.beginRetreat('flee');
      return true;
    }
    // E4:5 分钟滑窗里战斗占比超标 → 冷却,不自动进场
    if (!hurt && !this.opts.tuning().arena && this.busyRatioNow() > this.opts.tuning().busyRatio / 100) {
      this.cooldownUntil = Date.now() + this.opts.tuning().cooldownSec * 1000;
      if (!this.cooldownNoticed) {
        this.cooldownNoticed = true;
        this.opts.emit('这地方怪一波接一波,打不完,我得先离开这一片。', true, false);
      }
      return false;
    }
    this.cooldownNoticed = false;
    if (Date.now() < this.capCooldownUntil && !hurt) return false;
    this.bot = bot;
    this.state = initial;
    this.meleeEquip = null;
    this.rangedUnavailable = false;
    this.rangedBlocked = null;
    this.trackingLease = null;
    this.hadCombatWeapon = Boolean(bestWeapon(bot) || this.rangedReady(bot));
    const now = Date.now();
    this.controlSummary = { schemaVersion: 1, finalMode: 'fighting', enteredDesperate: false, retreat: null };
    this.startedAt = now;
    this.lifeEpisodeAtStart = this.life(bot)?.episodeId ?? null;
    this.healthBefore = bot.health ?? null;
    this.sceneBefore = this.observeScene(bot);
    this.sessionStartedAt = now;
    this.deadlineAt = now + this.opts.tuning().maxSec * 1000;
    this.lastStatusAt = now;
    this.emptySince = 0;
    this.lastProgressAt = now;
    this.lastRealProgressAt = now;
    this.lastLandedAt = now;
    this.lastReach = 99;
    this.targetId = -1;
    this.selectedTarget = null;
    this.swingPhase = 'idle';
    this.desperate = false;
    this.retreatBank = null;
    this.pathing = false;
    this.pathRetryAfter = 0;
    this.blockedHeadings.length = 0;
    this.trajectoryAt = now;
    this.trajectoryPos = { x: bot.entity.position.x, y: bot.entity.position.y, z: bot.entity.position.z };
    this.movementIntent = null;
    this.stallSince = 0;
    this.stallMode = '';
    this.targetDeaths = new Map();
    this.targetDeathsPending = new Map();
    this.struck.clear();
    this.deadIds.clear();
    this.swings = 0;
    this.landed = 0;
    this.lastSwingTargetId = -1;
    this.hybridWeapon = this.selectDefensiveWeapon({phase:'start',current:'melee',heldItem:bot.heldItem?.name??null,
      rangedReady:this.rangedReady(bot),meleeReady:Boolean(bestWeapon(bot)),distance:null});
    this.rangedOwner = {};
    this.rangedPendingOwner = null;
    this.nextRangedAt = now;
    this.arrows = 0;
    this.rangedLanded = 0;
    this.lastRangedHitTargetId = -1;
    this.lastRangedHitAt = 0;
    this.ctxPrevI.fill(0);
    this.ctxPrevD.fill(0);
    this.ctxTerrainAt = 0;
    this.ctxCreeperAt = 0;
    this.coverAt = 0;
    this.coverCell = null;
    const trialClear = !hurt && this.opts.tuning().arena === true;
    this.opts.suspendTasks(`战斗:${trialClear ? '试炼清怪' : hurt ? '被' : ''}${zhEntity(firstName)}${hurt ? '打了' : trialClear ? '' : '贴到跟前'}`);
    this.releaseWalkOnly ??= walkOnlyPath(bot);
    this.hook(bot);
    const held = initial === 'fighting' ? this.hybridWeapon === 'ranged'
      ? ',保留已经拿好的弓，拉开距离还击' : this.armMelee(bot) : '';
    this.opts.emit(
      initial === 'tracking' ? `先和${zhEntity(firstName)}保持距离，跟进观察，不主动出手。`
      : hurt
        ? `有只${zhEntity(firstName)}打过来了,我抄家伙还手!(生命 ${this.hp()}/20${held})`
        : trialClear
          ? `试炼层发现${zhEntity(firstName)},我主动清怪!(生命 ${this.hp()}/20${held})`
          : `${zhEntity(firstName)}贴到跟前了,我先动手!(生命 ${this.hp()}/20${held})`,
      true, hurt,
    );
    this.opts.diag?.write({
      lane: 'combat', event: 'engage',
      msg: `开打:${firstName}${hurt ? '(挨了打)' : trialClear ? '(试炼主动清怪)' : '(近身触发)'},生命 ${this.hp()}/20`,
      data: { first: firstName, hurt, health: this.bot.health },
    });
    return true;
  }

  private hook(bot: Bot): void {
    bot.on('physicsTick', this.onTick);
    bot.on('entityDead' as never, this.onDead as never);
    bot.on('entityHurt' as never, this.onFoeHurt as never);
    bot.on('death', this.onSelfDeath);
  }

  private unhook(): void {
    const bot = this.bot;
    if (!bot) return;
    bot.removeListener('physicsTick', this.onTick);
    bot.removeListener('entityDead' as never, this.onDead as never);
    bot.removeListener('entityHurt' as never, this.onFoeHurt as never);
    bot.removeListener('death', this.onSelfDeath);
  }

  /** 刚挥的那一刀落没落在目标身上:掉血在挥刀后一个往返内到,超窗的算别人打的 */
  private noteFoeHurt(e: { id?: number }, source?: { id?: number }): void {
    if (this.state === 'idle' || typeof e.id !== 'number') return;
    if (typeof source?.id === 'number' && source.id !== this.bot?.entity.id) return;
    if (e.id === this.lastRangedHitTargetId && Date.now() - this.lastRangedHitAt <= LANDED_WINDOW_MS) {
      this.lastRangedHitTargetId = -1;
      return;
    }
    if (e.id !== this.lastSwingTargetId) return;
    if (Date.now() - this.lastSwingAt > LANDED_WINDOW_MS) return;
    this.landed += 1;
    this.lastLandedAt = Date.now();
    this.lastSwingTargetId = -1; // 一刀只记一次命中
  }

  private rememberStruck(id: number): void {
    const entity = this.bot?.entities[id];
    if (entity) this.struck.set(id, captureDeathTarget(entity));
  }

  private noteDead(e: { id?: number; uuid?: string; name?: string }): void {
    if (this.state === 'idle' || typeof e.id !== 'number') return;
    const selected = this.struck.get(e.id);
    if (selected && !matchesDeathTarget(this.bot?.entities, selected, e)) return;
    this.deadIds.add(e.id);
    if (!selected) return;
    this.struck.delete(e.id);
    const name = e.name ?? 'unknown';
    this.targetDeaths.set(name, (this.targetDeaths.get(name) ?? 0) + 1);
    this.targetDeathsPending.set(name, (this.targetDeathsPending.get(name) ?? 0) + 1);
    const now = Date.now();
    if (now - this.lastKillEmitAt < KILL_MERGE_MS) return;
    this.lastKillEmitAt = now;
    const parts = [...this.targetDeathsPending].map(([n, c]) => `${zhEntity(n)}${c > 1 ? `×${c}` : ''}`);
    this.targetDeathsPending = new Map();
    const t = this.opts.tuning();
    const left = this.bot
      ? this.exitFoes(
          this.scan(this.bot, t, this.rangedReady(this.bot) ? RANGED_EXIT_RANGE : undefined), t,
        ).filter((f) => f.visible).length
      : 0;
    this.opts.emit(
      `观察到${parts.join('、')}死亡，未确认本人击杀归属。${left > 0 ? `还有 ${left} 只在。` : '周围没别的了。'}`,
      true, false,
    );
  }

  /** 目标池:敌对、够近、不是打不过的;末影人只有惹过我们的才进(看它就是宣战) */
  private scan(bot: Bot, t: CombatTuning, maxFlat = t.chaseMax + 4): Foe[] {
    const out: Foe[] = [];
    for (const key of Object.keys(bot.entities)) {
      const e = bot.entities[key as unknown as number];
      if (!e?.isValid || !e.position || e === bot.entity) continue;
      if (this.deadIds.has(e.id)) continue;
      const name = e.name ?? '';
      const provoked = this.provoked.has(e.id);
      if (name === 'piglin') {
        if (!piglinIsHostile(bot, e, provoked)) continue;
      } else if (!HOSTILE.has(name) && !provoked) continue;
      if (name === 'enderman' && !provoked) continue;
      const flat = Math.hypot(e.position.x - bot.entity.position.x, e.position.z - bot.entity.position.z);
      // A ranged attacker identified from an unattributed hit may be farther
      // than the normal pursuit radius. Keep that specific threat in the fight
      // instead of entering the "empty arena" hold while still taking arrows.
      if (flat > maxFlat && !(provoked && RANGED.has(name) && flat <= 20)) continue;
      // 试炼塔楼层上下重叠，不能把隔层怪当成本层卡关目标。
      if (t.arena && Math.abs(e.position.y - bot.entity.position.y) > 4) continue;
      out.push({ id: e.id, name, ent: e as never, pos: e.position, reach: aabbReach(bot, e as never), flat,
        visible: canSeeEntity(bot, e) });
    }
    return out;
  }

  /**
   * 退出判据和剩余敌人数只统计常规半径内或已交手的目标。
   * 扩大的扫描半径本身不扩大退出范围；明确选择且身份仍匹配的可见目标
   * 须保留，否则会刚受理就误判附近无怪。
   */
  private exitFoes(foes: Foe[], t: CombatTuning): Foe[] {
    const near = t.chaseMax + 4;
    return foes.filter((f) => f.flat <= near || this.provoked.has(f.id) || this.isSelectedTarget(f));
  }

  private isSelectedTarget(foe: Foe): boolean {
    const selected = this.selectedTarget;
    return !!selected && foe.id === selected.id && foe.visible
      && (selected.uuid === null ? this.bot?.entities[foe.id] === selected.entity
        : this.bot?.entities[foe.id]?.uuid === selected.uuid);
  }

  /** An admitted explicit target stays selected while present and visible. */
  private pick(foes: Foe[]): Foe | null {
    const pool = foes.filter((f) => !NO_FIGHT.has(f.name));
    const selected = pool.find(f => this.isSelectedTarget(f));
    if (selected) { this.targetId = selected.id; return selected; }
    this.selectedTarget = null;
    if (pool.length === 0) return null;
    const best = [...pool].sort((a, b) => a.reach - b.reach)[0];
    const cur = pool.find((f) => f.id === this.targetId);
    if (cur && best.id !== cur.id && !(cur.reach > best.reach * 1.3)) return cur;
    this.targetId = best.id;
    return best;
  }

  /** 三形态:贴身 ≥2 只 → 横扫;否则暴击;远程怪贴脸暴击(推远了它就开始射) */
  private resolveMode(foes: Foe[], target: Foe): 'crit' | 'kb' | 'sweep' {
    const bot = this.bot!;
    // 水里 onGround 恒假，且无法保持横扫所需的站定状态，因此只用平 A。
    if (bodyInWater(bot)) return 'kb';
    const sword = (bot.heldItem?.name ?? '').endsWith('_sword');
    const crowd = foes.filter((f) => f.reach <= 3.4).length;
    if (sword && crowd >= SWEEP_CROWD) return 'sweep';
    if (crowd >= KB_CROWD) return 'kb';
    const others = foes.filter((f) => f.id !== target.id).map((f) => f.flat).sort((a, b) => a - b);
    const space = others.length === 0 || others[0] > SOLO_SPACE;
    if (space || RANGED.has(target.name)) return 'crit';
    return 'kb';
  }

  /** 4 Hz 战斗轨迹；位移对应上一采样区间的方向键，用于识别“看似在跑、其实顶墙”。 */
  private sampleTrajectory(): void {
    const bot = this.bot;
    if (this.state === 'idle' || !bot?.entity) return;
    const now = Date.now();
    if (now - this.trajectoryAt < TRAJECTORY_SAMPLE_MS) return;
    const p = bot.entity.position;
    const prev = this.trajectoryPos;
    const intent = this.movementIntent;
    const dx = prev ? p.x - prev.x : 0;
    const dz = prev ? p.z - prev.z : 0;
    const moved = Math.hypot(dx, dz);
    const progress = intent ? dx * intent.x + dz * intent.z : 0;
    const mode = this.state === 'retreating' ? 'retreat' : this.pathing ? 'path' : this.hybridWeapon;
    const controls = bot.controlState;
    const pressing = Boolean(controls.forward || controls.back || controls.left || controls.right);
    const movement = this.state === 'retreating' ? this.controlSummary.retreat?.movement : null;
    if (movement) {
      movement.samples++;
      if (pressing) movement.horizontalActiveSamples++;
      if (intent) movement.horizontalIntentSamples++;
      if (controls.jump && !pressing) movement.jumpOnlySamples++;
      // Position deltas include knockback; this is observed displacement, not verified escape.
      const previousRetreatSample = this.retreatSamplePosition;
      if (previousRetreatSample) movement.observedHorizontalDistance = Math.round((movement.observedHorizontalDistance
        + Math.hypot(p.x - previousRetreatSample.x, p.z - previousRetreatSample.z)) * 1000) / 1000;
      this.retreatSamplePosition = { x: p.x, z: p.z };
      movement.lastRejection = this.lastMovementRejection;
    }
    const target = bot.entities[this.targetId];
    const ahead = intent ? p.offset(intent.x * 0.8, 0, intent.z * 0.8) : null;
    this.opts.diag?.write({
      lane: 'combat', event: 'trajectory', level: 'debug', msg: '战斗轨迹采样',
      data: {
        state: this.state, mode, health: bot.health, food: bot.food,
        pos: { x: +p.x.toFixed(2), y: +p.y.toFixed(2), z: +p.z.toFixed(2) },
        yaw: +bot.entity.yaw.toFixed(2),
        moved: +moved.toFixed(3), progress: +progress.toFixed(3),
        intent, slot: intent ? +dirSlot(intent.x, intent.z).toFixed(1) : null,
        controls: { forward: !!controls.forward, back: !!controls.back,
          left: !!controls.left, right: !!controls.right, jump: !!controls.jump, sprint: !!controls.sprint },
        target: target?.position ? { id: target.id, name: target.name,
          x: +target.position.x.toFixed(2), y: +target.position.y.toFixed(2), z: +target.position.z.toFixed(2) } : null,
        ahead: ahead ? { feet: bot.blockAt(ahead)?.name, head: bot.blockAt(ahead.offset(0, 1, 0))?.name } : null,
      },
    });
    this.trajectoryAt = now;
    this.trajectoryPos = { x: p.x, y: p.y, z: p.z };

    // 寻路器还在算路径、尚未按方向键时不算顶墙。
    // Retreat jumps and lateral knockback do not establish progress along the
    // commanded route. Reuse the same bounded heading exclusion even airborne.
    const retreat = this.state === 'retreating';
    const checking = (bot.entity.onGround || retreat) && !bodyInWater(bot) && pressing &&
      (this.pathing || intent !== null);
    if (!checking || (retreat ? progress : moved) >= 0.06) { this.stallSince = 0; this.stallMode = ''; return; }
    if (this.stallMode !== mode) { this.stallMode = mode; this.stallSince = now; return; }
    if (now - this.stallSince < MOVEMENT_STALL_MS) return;
    this.stallSince = now;
    if (this.pathing) {
      this.pathing = false;
      this.pathRetryAfter = now + 2_500;
      dropOwnedGoal(bot, 'combat', '战斗寻路顶墙,改为局部绕行', this.opts.diag);
    } else if (intent) {
      this.blockedHeadings.push({ ...intent, until: now + 2_500 });
      if (this.blockedHeadings.length > 4) this.blockedHeadings.shift();
      this.ctxTerrainAt = 0;
      this.coverCell = null;
      this.stopMovement(bot);
    }
    this.opts.diag?.write({
      lane: 'combat', event: 'wall-stall', incident: true,
      msg: `战斗${mode}原地顶墙超过 ${MOVEMENT_STALL_MS}ms,换方向`,
      data: { mode, pos: { x: p.x, y: p.y, z: p.z }, intent,
        targetId: this.targetId, pathRetryAfter: this.pathRetryAfter },
    });
  }

  private tick(): void {
    if (this.state === 'idle') return;
    const bot = this.bot;
    if (!bot?.entity || bot !== this.opts.getBot()) { this.end('gone'); return; }
    if (this.bodyEnded(bot)) { this.end('death'); return; }
    if (!this.alive(bot)) { this.end('gone'); return; }
    const now = Date.now();
    // E6:环境自保找上门(岩浆/溺水),战斗静默让位,由环境反射自己汇报
    if (this.opts.envBusy()) { this.end('env'); return; }
    // 会话级总_cap:振荡(fight↔retreat)会不断重置各分支时限,这道闸只看 engage 起点
    if (now - this.sessionStartedAt > COMBAT_TOTAL_CAP_MS) {
      this.opts.emit(`缠太久了,我先脱战喘口气——剩下的怪交给距离和时间。(生命 ${this.hp()}/20)`, true, false);
      this.capCooldownUntil = now + 60_000;
      this.end('timeout');
      return;
    }
    this.equipSpareTotem(bot, now);
    if (this.state === 'retreating') { this.retreatTick(bot, now); return; }
    if (this.tracking) { this.trackTick(bot, now); return; }

    const t = this.opts.tuning();
    const rangedReady = this.rangedReady(bot);
    const armed = Boolean(bestWeapon(bot) || rangedReady);
    if (!this.desperate && !armed && this.hadCombatWeapon) { this.retreatUnarmed(); return; }
    this.hadCombatWeapon ||= armed;
    const foes = this.scan(
      bot,
      t,
      this.desperate ? RETREAT_CLEAR_DIST : Math.max(rangedReady ? RANGED_EXIT_RANGE : t.chaseMax + 4,
        this.selectedTarget ? Math.min(32, Math.max(0, t.decisionRange ?? 0)) : 0),
    );
    // E1:没怪了,滞后 3s 收工(防"炸完→退出→新怪→再进入"刷屏)。
    // 「没怪了」按退出口径算(见 exitFoes):远处那些没交过手的不算数,
    // 否则夜里 40 格内总有一只,这一局就永远收不了工。
    const visibleFoes = foes.filter((f) => f.visible);
    const clearPool = this.desperate ? visibleFoes : this.exitFoes(visibleFoes, t);
    if (clearPool.length === 0) {
      if (this.emptySince === 0) this.emptySince = now;
      this.opts.ranged?.abort();
      this.rangedPendingOwner = null;
      this.hybridWeapon = 'melee';
      this.release(bot);
      if (this.tryCombatFood(bot, foes, now)) return;
      if (now - this.emptySince >= CLEAR_HOLD_MS) this.endClear();
      return;
    }
    this.emptySince = 0;

    // E3:硬时长。刷怪笼、夜晚开阔地的"索得到敌"可以永久为真,没有这道闸
    // 就是脚本永久持有控制权、人格整场没有手
    if (now >= this.deadlineAt) {
      this.opts.emit(`打太久了,先收手——还有 ${foes.length} 只在附近,怎么办你来定。(生命 ${this.hp()}/20)`, true, false);
      this.end('timeout');
      return;
    }
    // E2:血线只在场上仍有活威胁时撤。死亡事件到实体表移除之间不能把已清场误判成逃跑。
    // 转身还手中不看——血线的前提是"跑得掉",cornered 正是跑不掉才回的头。
    if (!this.desperate && (bot.health ?? 20) < t.fleeHealth) {
      this.opts.emit(`血被打到 ${this.hp()}/20 了,我先撤!`, true, true);
      this.beginRetreat('flee');
      return;
    }
    if (this.tryCombatFood(bot, foes, now)) return;

    // 出手相位一旦起了就必须走完:台架第一轮 crit/sweep 整场只挥得出 2–4 刀,
    // 就是因为别的分支每 tick 把起跳/站定重置掉
    if (this.swingPhase !== 'idle') {
      const held = visibleFoes.find((f) => f.id === this.phaseTargetId);
      if (!held) { this.swingPhase = 'idle'; bot.setControlState('jump', false); }
      else {
        this.aimAt(bot, held);
        this.tryOffense(held, this.resolveMode(visibleFoes, held), now);
        return;
      }
    }

    const target = this.pick(visibleFoes);
    if (!target) {
      // 场上只剩打不过的(E7):撤
      this.opts.emit(`剩下的是${zhEntity(foes[0].name)},这个打不过,撤!`, true, false);
      this.beginRetreat('no-fight');
      return;
    }

    // 近战触及目标须同时满足距离和视线：原版服务端近战不检查墙体。
    if (target.reach < this.lastReach - 0.3) this.lastProgressAt = now;
    this.lastReach = target.reach;
    if (target.reach <= REACH_MAX && this.losTo(bot, target)) {
      this.lastProgressAt = now;
      this.lastRealProgressAt = now;
    }
    if (now - Math.max(this.lastProgressAt, this.lastLandedAt) > UNREACHABLE_MS) {
      this.opts.emit(`够不着${zhEntity(target.name)},不耗了。(生命 ${this.hp()}/20)`, true, false);
      this.end('stuck');
      return;
    }
    // 绝对时限只由实际可达或命中重置，reach 差分只刷新上面的软窗口。
    if (now - Math.max(this.lastRealProgressAt, this.lastLandedAt) > UNREACHABLE_HARD_MS) {
      this.opts.emit(
        `缠了 ${Math.round(UNREACHABLE_HARD_MS / 1000)} 秒始终够不到${zhEntity(target.name)},不耗了。(生命 ${this.hp()}/20)`,
        true, false,
      );
      this.end('stuck');
      return;
    }

    // 挥刀达到门槛后仍未命中则收工；空挥不刷新命中时间。
    if (this.swings >= NO_DAMAGE_SWINGS && now - this.lastLandedAt > NO_DAMAGE_MS) {
      this.opts.emit(
        `挥了 ${this.swings} 刀一下都没打到${zhEntity(target.name)},不耗了。(生命 ${this.hp()}/20)`,
        true, false,
      );
      this.end('stuck');
      return;
    }

    if (this.swings === 0 && this.arrows === 0 && now - this.startedAt > NO_SWING_MS) {
      this.opts.emit(
        `进场 ${Math.round(NO_SWING_MS / 1000)} 秒一下手都没出上(${zhEntity(target.name)}),不耗了。(生命 ${this.hp()}/20)`,
        true, false,
      );
      this.end('stuck');
      return;
    }

    // Having a bow does not make the empty melee hand armed. With no melee
    // weapon, keep the ranged controller's spacing instead of choosing fists
    // merely because the hostile crossed the hybrid distance threshold.
    const weapon = this.selectDefensiveWeapon({phase:'tick',current:this.hybridWeapon,heldItem:bot.heldItem?.name??null,
      rangedReady,meleeReady:Boolean(bestWeapon(bot)),distance:target.reach});
    if (weapon !== this.hybridWeapon) this.switchWeapon(bot, weapon);
    if (this.hybridWeapon === 'ranged') {
      this.driveRanged(bot, target, visibleFoes, now);
      return;
    }

    this.aimAt(bot, target);

    // 接近卡住 1.5s 交给寻路器,够得着立刻收回来自己打
    if (!this.pathing && target.reach > 3.4 && now - this.lastProgressAt > STUCK_PATH_MS && now >= this.pathRetryAfter) {
      this.pathing = true;
      this.movementIntent = null;
      this.pathUntil = now + 4_000;
      setOwnedGoal(bot, new goals.GoalFollow(target.ent as never, 2), 'combat', '接近目标', { dynamic: true, diag: this.opts.diag });
    }
    if (this.pathing) {
      if (target.reach <= 3.2 || now > this.pathUntil) {
        // 走到了才算进展;窗口空转到期不算,否则 E5 被这条无限续命
        if (target.reach <= 3.2) {
          this.lastProgressAt = now;
          this.lastRealProgressAt = now;
        }
        this.pathing = false;
        dropOwnedGoal(bot, 'combat', '够得着了,收回来自己打', this.opts.diag);
      } else {
        // 寻路期间视线归寻路器:两边每 tick 各拧一次,镜头里就是原地疯狂旋转
        if (this.canSwing(now) && target.reach <= REACH_MAX) {
          this.aimAt(bot, target);
          this.tryOffense(target, this.resolveMode(visibleFoes, target), now);
        }
        this.statusTick(bot, visibleFoes, now);
        return;
      }
    }

    const mode = this.resolveMode(visibleFoes, target);
    this.shieldLogic(bot, visibleFoes, now);
    this.driveContext(bot, t, target, mode, now, visibleFoes);
    this.tryOffense(target, mode, now);
    this.statusTick(bot, visibleFoes, now);
  }

  /**
   * 看向目标。够得着才低头瞄它身上——攻击射线要打在碰撞箱上,矮个子(蜘蛛、小僵尸)
   * 本来就得低头。够不着就平视它的方向:那一刀反正打不出去,盯着脚下那一格只换来
   * 镜头里一个对着地板转圈的人。
   */
  private aimAt(bot: Bot, f: Foe): void {
    const y = f.reach <= REACH_MAX
      ? f.pos.y + (f.ent.height ?? 1.8) * 0.75
      : bot.entity.position.y + EYE;
    void bot.lookAt(new Vec3(f.pos.x, y, f.pos.z), true).catch(() => undefined);
  }

  /** 这一刀看不看得见目标。原版服务端近战不查墙——隔墙发包真能打中,穿帮得我们自己拦 */
  private losTo(bot: Bot, f: Foe): boolean {
    return canSeeEntity(bot, f.ent);
  }

  /** 战况:每 6s 一条,不唤醒(接敌/击杀/撤退才唤醒) */
  private statusTick(bot: Bot, foes: Foe[], now: number): void {
    if (now - this.lastStatusAt < STATUS_EVERY_MS) return;
    this.lastStatusAt = now;
    const nearest = [...foes].sort((a, b) => a.reach - b.reach)[0];
    this.opts.emit(
      `还在打:${foes.length} 只在附近(最近的是${zhEntity(nearest.name)}),` +
        `刀 ${this.swings} 次命中 ${this.meleeLanded()} 次,箭 ${this.arrows} 支命中 ${this.rangedLanded} 次,` +
        `手里是${heldText(bot)},生命 ${this.hp()}/20。`,
      false, false,
    );
  }

  private rangedReady(bot: Bot): boolean {
    return (!this.active || !this.rangedUnavailable) && (this.opts.ranged?.ready(bot) ?? false);
  }

  private switchWeapon(bot: Bot, next: HybridWeapon): void {
    this.hybridWeapon = next;
    this.swingPhase = 'idle';
    bot.setControlState('jump', false);
    if (next === 'ranged') {
      if (this.pathing) {
        this.pathing = false;
        dropOwnedGoal(bot, 'combat', '改用远程,寻路器让位', this.opts.diag);
      }
      this.lowerShield(bot);
      return;
    }
    this.opts.ranged?.abort();
    this.rangedPendingOwner = null;
    this.armMelee(bot);
  }

  /**
   * 把近战最好的那件拿到主手,返回接敌播报里那半句。已经在手上就不动;
   * 要换时播报只说正在换,换手的结果出来后没拿到手就另发一条,写明原因和手里实际是什么。
   */
  private armMelee(bot: Bot): string {
    const weapon = bestWeapon(bot);
    if (!weapon) return ',手边没趁手的家伙';
    if (bot.heldItem?.name === weapon.name) return `,手里是${zhName(weapon.name)}`;
    if (this.meleeEquip?.bot === bot) return ',正在核对换手结果';
    const attempt: NonNullable<CombatSession['meleeEquip']> = { bot, weapon: weapon.name, startedAt: Date.now(), failed: false };
    this.meleeEquip = attempt;
    const was = heldText(bot);
    const miss = (why: string): void => {
      if (this.meleeEquip !== attempt || this.bot !== bot || this.state !== 'fighting') return;
      attempt.failed = true;
      const now = heldText(bot);
      this.opts.emit(`${zhName(weapon.name)}没换到手上(${why}),手里是${now}。`, true, false);
      this.opts.diag?.write({
        lane: 'combat', event: 'arm-miss',
        msg: `近战换${weapon.name}没成:${why},主手是${now}`,
        data: { weapon: weapon.name, held: bot.heldItem?.name ?? null, why },
      });
    };
    void equipHandConfirmed(bot, weapon, () => {
      if (this.meleeEquip !== attempt || this.bot !== bot || this.state !== 'fighting' || attempt.failed)
        throw new Error('原战斗已让出身体，不继续换手');
    }).then(
      () => {
        if (this.meleeEquip !== attempt) return;
        if (bot.heldItem?.name !== weapon.name) miss('换手做完了,主手读数却不是它');
        else this.meleeEquip = null;
      },
      (err: Error) => miss(zhErrorText(err.message)),
    );
    return `,正把${zhName(weapon.name)}换到手上(原来手里是${was})`;
  }

  /** Inventory availability is not equip confirmation. Never swing while the
   * selected weapon is still in the bag; keep movement/retreat independent. */
  private meleeHandReady(bot: Bot, now: number): boolean {
    if (weaponScore(bot.heldItem?.name ?? '') >= 0) return true;
    if (!bestWeapon(bot)) return true; // Existing unarmed/escape policy owns this case.
    if (!this.meleeEquip) this.armMelee(bot);
    const attempt = this.meleeEquip;
    if (!attempt) return false;
    if (!attempt.failed && now - attempt.startedAt < 3_000) return false;
    if (!attempt.failed) {
      attempt.failed = true;
      this.opts.emit(`换${zhName(attempt.weapon)}超过3秒仍未确认，手里是${heldText(bot)}。`, true, false);
    }
    // Cornered status cannot turn a failed equipment transaction into a
    // confirmed weapon. The truly unarmed policy was handled above.
    this.opts.emit('武器没能拿到手，先拉开距离再处理装备。', true, false);
    this.beginRetreat('flee');
    return false;
  }

  private driveRanged(bot: Bot, target: Foe, foes: Foe[], now: number): void {
    this.lowerShield(bot);
    const dx = target.pos.x - bot.entity.position.x;
    const dz = target.pos.z - bot.entity.position.z;
    if (target.reach > 14) {
      this.driveRangedDirection(bot, [
        { x: dx, z: dz }, { x: -dz, z: dx }, { x: dz, z: -dx },
      ], true);
    } else if (target.reach < 8) {
      this.driveRangedDirection(bot, [
        { x: -dx, z: -dz }, { x: -dz, z: dx }, { x: dz, z: -dx },
      ], true);
    } else if (inKiteRange(target.reach)) {
      this.driveRangedDirection(bot, [
        { x: -dz, z: dx },
        { x: dz, z: -dx },
      ], true);
    } else {
      this.stopMovement(bot);
    }
    this.tryRanged(target, now);
    this.statusTick(bot, foes, now);
  }

  /** 弓态不靠寻路器接管视线；只在实际移动方向有干燥落脚格时写水平键。 */
  private driveRangedDirection(
    bot: Bot,
    candidates: Array<{ x: number; z: number }>,
    sprint: boolean,
  ): void {
    const direction = candidates.find((d) => this.rangedDirectionSafe(bot, d.x, d.z));
    if (!direction) {
      this.stopMovement(bot);
      if (bodyInWater(bot)) bot.setControlState('jump', true);
      return;
    }
    this.pressToward(bot, direction.x, direction.z, sprint);
    this.autoJump(bot, direction.x, direction.z);
  }

  private rangedDirectionSafe(bot: Bot, dx: number, dz: number): boolean {
    return this.movementSafe(bot, dx, dz, true);
  }

  private rangedStandable(bot: Bot, x: number, y: number, z: number): boolean {
    const below = bot.blockAt(new Vec3(x, y - 1, z));
    const feet = bot.blockAt(new Vec3(x, y, z));
    const head = bot.blockAt(new Vec3(x, y + 1, z));
    if (!below || !feet || !head) return false;
    const liquid = (name: string): boolean => name === 'water' || name === 'lava' || name === 'bubble_column';
    return below.boundingBox === 'block' && !SCORCHING_FLOOR.has(below.name) &&
      !BURNING_BLOCKS.has(below.name) && feet.boundingBox === 'empty' && head.boundingBox === 'empty' &&
      !liquid(feet.name) && !liquid(head.name);
  }

  private tryRanged(target: Foe, now: number): void {
    const ranged = this.opts.ranged;
    const owner = this.rangedOwner;
    if (!ranged || !owner || this.rangedPendingOwner || ranged.active() || now < this.nextRangedAt) return;
    this.nextRangedAt = now + 250;
    this.rangedPendingOwner = owner;
    void ranged.shoot({
      id: target.id,
      position: target.pos,
      height: target.ent.height,
      width: target.ent.width,
    }, owner).then(result => {
      if (result.kind === 'blocked') this.onRangedBlocked(owner, target.id, result);
    }).catch((error: unknown) => {
      this.opts.log.warn(`远程出手失败:${error instanceof Error ? error.message : String(error)}`);
      this.onRangedBlocked(owner, target.id, { kind: 'blocked', reason: 'aborted', cause: 'activate' });
    }).finally(() => {
      if (this.rangedPendingOwner === owner) this.rangedPendingOwner = null;
    });
  }

  private onRangedBlocked(owner: unknown, targetId: number, result: Extract<BowShotResult, { kind: 'blocked' }>): void {
    if (!this.ownsRanged(owner) || !this.bot || this.bodyEnded(this.bot)) return;
    if (result.cause && ['abort', 'lease', 'death', 'bot_lost'].includes(result.cause)) return;
    const now = Date.now(), previous = this.rangedBlocked;
    this.rangedBlocked = { firstAt: previous?.firstAt ?? now, reason: result.reason, cause: result.cause };
    if (!previous || previous.reason !== result.reason || previous.cause !== result.cause) {
      this.opts.diag?.write({ lane: 'combat', event: 'ranged-blocked', msg: '弓箭执行未完成',
        data: { targetId, reason: result.reason, cause: result.cause ?? null, held: this.bot.heldItem?.name ?? null } });
    }
    const equipmentFailure = result.reason === 'no_arrow'
      || ['equip', 'equip_timeout', 'bow_lost', 'cancel_slot', 'activate', 'release'].includes(result.cause ?? '');
    // LOS and a busy hand may recover while spacing. They cannot keep an idle
    // controller labelled as attacking for the whole six-second stuck window.
    if (!equipmentFailure && now - this.rangedBlocked.firstAt < 1_500) return;
    this.rangedUnavailable = true;
    this.opts.emit(`弓箭未能出手(${result.cause ?? result.reason})，主手是${heldText(this.bot)}。` +
      (bestWeapon(this.bot) ? '核对近战武器后再打。' : '先撤离，不用手里物品继续攻击。'), true, false);
    if (bestWeapon(this.bot)) this.switchWeapon(this.bot, 'melee');
    else this.beginRetreat('flee');
  }

  private meleeLanded(): number {
    return Math.max(0, this.landed - this.rangedLanded);
  }

  // —— v7 移动:上下文图 ————————————————————————————————————————

  private driveContext(bot: Bot, t: CombatTuning, target: Foe, mode: 'crit' | 'kb' | 'sweep', now: number, foes: Foe[]): void {
    const shortMove = this.tacticalMove;
    if (shortMove) {
      const remaining = shortMove.destination.minus(bot.entity.position);
      if (now >= shortMove.expiresAtMs || remaining.norm() < 0.22
        || !corridorSafe(bot, shortMove.origin, shortMove.destination)) this.tacticalMove = null;
      else { this.pressToward(bot, remaining.x, remaining.z, false); return; }
    }
    // 横扫要求出手那一 tick 几乎没动:站定期间任何移动都不许写
    if (this.swingPhase === 'settle') {
      for (const k of ['forward', 'back', 'left', 'right', 'sprint'] as const) bot.setControlState(k, false);
      this.movementIntent = null;
      return;
    }
    const I = this.ctxI;
    const D = this.ctxD;
    I.fill(0);
    D.fill(0);
    const me = bot.entity.position;

    // interest:亚格间距。贴着攻击距离上沿做比例控制,把目标的接近速度补进误差——
    // 它以 v 逼近,我就以 v 后退(spacing,单独值 1.8×)
    const tx = target.pos.x - me.x, tz = target.pos.z - me.z;
    const tlen = Math.hypot(tx, tz) || 1;
    const ideal = RANGED.has(target.name) ? RANGED_STOP : t.space;
    const tv = (target.ent as unknown as { velocity?: { x: number; z: number } }).velocity;
    const closing = tv ? -((tv.x * tx + tv.z * tz) / tlen) * 20 : 0;
    const err = (target.reach - closing * SPACE_PREDICT_S) - ideal;
    if (err > 0.10) write(I, tx, tz, Math.min(1.0, 0.45 + err), 1);
    else if (err < -0.10) write(I, -tx, -tz, Math.min(1.0, 0.45 - err), 1);

    // interest:公转。两侧切向都写,怪少的那侧写得更强——绕着走把它们叠成一个扇区,
    // 同时能碰到你的嘴变少,横扫一刀吃到的反而多
    const lx = -tz / tlen, lz = tx / tlen;
    let leftMass = 0, rightMass = 0;
    for (const f of foes) {
      if (f.flat > 8) continue;
      const lat = (f.pos.x - me.x) * lx + (f.pos.z - me.z) * lz;
      const w = 1 / (1 + f.flat);
      if (lat > 0) leftMass += w;
      else rightMass += w;
    }
    write(I, lx, lz, leftMass <= rightMass ? 0.75 : 0.4, 2);
    write(I, -lx, -lz, rightMass < leftMass ? 0.75 : 0.4, 2);

    // interest:掩体(退进更窄的落脚格)。只是写图的一个行为,不独占方向盘
    this.pickCoverCell(bot, foes, now);
    const c = this.coverCell;
    if (c && !this.coverArrived(bot)) {
      write(I, c.x + 0.5 - me.x, c.z + 0.5 - me.z, 0.65, 2);
    }

    // danger:怪群
    for (const f of foes) {
      if (f.flat > 10) continue;
      write(D, f.pos.x - me.x, f.pos.z - me.z, 1.6 / (1 + f.flat * 0.55), 2);
    }
    // danger:苦力怕圈(往「走过去仍在圈内且它看得见我」的方向写重危险;
    // 被方块挡住视线的方向不写——「绕到柱子后面」是图的自然结果,不是一个模式)
    this.writeCreeperDanger(bot, D, foes, now);
    // danger:地形硬 masking
    this.writeTerrainDanger(bot, D, now);

    blur(I);
    blur(D);
    blend(this.ctxPrevI, I, 0.45);
    blend(this.ctxPrevD, D, 0.55);
    this.ctxPrevI.set(I);
    this.ctxPrevD.set(D);

    let choice = decide(I, D, 0.25);
    // 抛物线插值和按键量化后的实际方向可能越过被屏蔽的墙角；出手前复查。
    for (let tries = 0; choice && tries < 16 && !this.movementSafe(bot, choice.x, choice.z); tries++) {
      writeSlot(D, choice.slot, HARD);
      choice = decide(I, D, 0.25);
    }
    if (!choice || !this.movementSafe(bot, choice.x, choice.z)) { this.release(bot); return; }
    this.pressToward(bot, choice.x, choice.z, choice.strength > 0.7 && mode === 'kb');
    this.autoJump(bot, choice.x, choice.z);
  }

  /** 每 150ms 重算:16 条射线不该每 tick 都打 */
  private writeCreeperDanger(bot: Bot, D: Map16, foes: Foe[], now: number): void {
    if (now - this.ctxCreeperAt > 150) {
      this.ctxCreeperAt = now;
      this.ctxCreeper.fill(0);
      const me = bot.entity.position;
      for (const f of foes) {
        if (f.name !== 'creeper' || f.flat > 8) continue;
        for (let i = 0; i < 16; i++) {
          const d = slotDir(i);
          const px = me.x + d.x * 2.2, pz = me.z + d.z * 2.2;
          if (Math.hypot(px - f.pos.x, pz - f.pos.z) > CREEPER_SAFE) continue;
          const eye = new Vec3(px, me.y + EYE, pz);
          if (!hasLosFrom(bot, eye, f.ent as never)) continue;
          writeSlot(this.ctxCreeper, i, 3.0);
        }
      }
    }
    for (let i = 0; i < 16; i++) writeSlot(D, i, this.ctxCreeper[i]);
  }

  /** 每 200ms 重算:走不过去的方向直接 HARD,永不入选 */
  private writeTerrainDanger(bot: Bot, D: Map16, now: number): void {
    if (now - this.ctxTerrainAt > 200) {
      this.ctxTerrainAt = now;
      this.ctxTerrain.fill(0);
      for (let i = 0; i < 16; i++) {
        const d = slotDir(i);
        if (this.movementSafe(bot, d.x, d.z)) continue;
        writeSlot(this.ctxTerrain, i, HARD);
      }
    }
    for (let i = 0; i < 16; i++) writeSlot(D, i, this.ctxTerrain[i]);
  }

  private standable(bot: Bot, x: number, y: number, z: number): boolean {
    const below = bot.blockAt(new Vec3(x, y - 1, z));
    const feet = bot.blockAt(new Vec3(x, y, z));
    const head = bot.blockAt(new Vec3(x, y + 1, z));
    if (!below || !feet || !head) return false;
    // 岩浆的 boundingBox 是 empty；危险方块须额外按与 world.ts 共用的名称集合排除。
    if (BURNING_BLOCKS.has(feet.name) || BURNING_BLOCKS.has(head.name)) return false;
    if (BURNING_BLOCKS.has(below.name) || SCORCHING_FLOOR.has(below.name)) return false;
    return below.boundingBox === 'block' && feet.boundingBox === 'empty' && head.boundingBox === 'empty';
  }

  /** 按方向键后真正产生的八向移动，不能用未量化的意图来检查地形。 */
  private appliedDirection(bot: Bot, dx: number, dz: number): { x: number; z: number } | null {
    const len = Math.hypot(dx, dz);
    if (len < 1e-6) return null;
    const y = bot.entity.yaw;
    const f = (dx * -Math.sin(y) + dz * -Math.cos(y)) / len;
    const l = (dx * -Math.cos(y) + dz * Math.sin(y)) / len;
    const forward = f > 0.35 ? 1 : f < -0.35 ? -1 : 0;
    const left = l > 0.35 ? 1 : l < -0.35 ? -1 : 0;
    const ax = forward * -Math.sin(y) + left * -Math.cos(y);
    const az = forward * -Math.cos(y) + left * Math.sin(y);
    const actualLen = Math.hypot(ax, az);
    return actualLen > 0 ? { x: ax / actualLen, z: az / actualLen } : null;
  }

  /** 角色宽 0.6 格；沿整段路径检查身体两侧，避开墙角、悬崖及近期实测顶墙方向。 */
  private movementSafe(bot: Bot, dx: number, dz: number, ranged = false, far = 1.4): boolean {
    const d = this.appliedDirection(bot, dx, dz);
    this.lastMovementRejection = null;
    if (!d) return this.rejectMovement('no_direction');
    const now = Date.now();
    if (this.blockedHeadings.some((b) => b.until > now && b.x * d.x + b.z * d.z > 0.9)) return this.rejectMovement('blocked_heading');
    const p = bot.entity.position;
    if (bodyInWater(bot)) return this.swimmingMovementSafe(bot, d, far);
    const y = Math.floor(p.y);
    const canStand = ranged ? this.rangedStandable.bind(this) : this.standable.bind(this);
    const nx = -d.z, nz = d.x;
    const ranges: number[] = [];
    for (let range = 0.55; range < far; range += 0.5) ranges.push(range);
    ranges.push(far);
    for (const range of ranges) {
      for (const side of [-0.31, 0, 0.31]) {
        const x = Math.floor(p.x + d.x * range + nx * side);
        const z = Math.floor(p.z + d.z * range + nz * side);
        if (![y, y + 1, y - 1].some((atY) => canStand(bot, x, atY, z))) return this.rejectMovement('unsafe_footing');
      }
    }
    return true;
  }

  private rejectMovement(reason: MovementRejection): false { this.lastMovementRejection = reason; return false; }

  /** Swimming still needs a known, unobstructed body corridor. Dry exits need full support. */
  private swimmingMovementSafe(bot: Bot, d: { x: number; z: number }, far: number): boolean {
    const p = bot.entity.position;
    const read = ([x, y, z]: [number, number, number]) => {
      const block = bot.blockAt(new Vec3(x, y, z));
      return block ? { material: { name: block.name, properties: block.getProperties?.() ?? null,
        collision: block.shapes ?? null, liquid: block.name === 'water' || block.name === 'lava' } }
        : { unknown: 'unloaded' };
    };
    let previous: [number, number, number] = [p.x, p.y, p.z];
    for (let range = 0; range <= far + .249; range += .25) {
      const distance = Math.min(range, far);
      let at: [number, number, number] = [p.x + d.x * distance, previous[1], p.z + d.z * distance];
      let body = spatialBody(read, previous, at);
      if (body.unknown) return this.rejectMovement('unknown_cell');
      if (body.hazard) return this.rejectMovement('hazard');
      if (body.collision || (!body.water && !body.supported)) {
        // Existing autoJump owns the one-block water-to-bank ascent. Verify both
        // its raised corridor and destination support; never assume a dry ledge is safe.
        const raised = Math.floor(p.y) + 1;
        const start: [number, number, number] = [previous[0], raised, previous[2]];
        at = [at[0], raised, at[2]];
        body = spatialBody(read, start, at);
        const lift = spatialBody(read, previous, start);
        if (raised - p.y > 1 || body.unknown || body.hazard || body.collision || !body.wetSupport
          || lift.unknown || lift.hazard || lift.collision) return this.rejectMovement(
            body.unknown || lift.unknown ? 'unknown_cell' : body.hazard || lift.hazard ? 'hazard'
              : body.collision || lift.collision ? 'collision' : 'no_support');
      }
      previous = at;
      if (distance === far) break;
    }
    return true;
  }

  /** 敞开度:八个水平方向里有几个是通的 */
  private openness(bot: Bot, x: number, y: number, z: number): number {
    let n = 0;
    for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]] as const) {
      const feet = bot.blockAt(new Vec3(x + dx, y, z + dz));
      const head = bot.blockAt(new Vec3(x + dx, y + 1, z + dz));
      if (feet?.boundingBox === 'empty' && head?.boundingBox === 'empty') n++;
    }
    return n;
  }

  /** 掩体:背离怪群那一侧找更窄的落脚格。任何穿过怪堆的移动都输,所以只往背面找 */
  private pickCoverCell(bot: Bot, foes: Foe[], now: number): void {
    if (now - this.coverAt < 900) return;
    this.coverAt = now;
    if (foes.length === 0) { this.coverCell = null; return; }
    const me = bot.entity.position;
    const base = me.floored();
    let cx = 0, cz = 0;
    for (const f of foes) { cx += f.pos.x; cz += f.pos.z; }
    cx /= foes.length;
    cz /= foes.length;
    const ax = me.x - cx, az = me.z - cz;
    const alen = Math.hypot(ax, az) || 1;
    const hereOpen = this.openness(bot, base.x, base.y, base.z);
    let best: { x: number; y: number; z: number } | null = null;
    let bestScore = -Infinity;
    for (let dx = -5; dx <= 5; dx++) {
      for (let dz = -5; dz <= 5; dz++) {
        const d = Math.hypot(dx, dz);
        if (d < 1 || d > 5) continue;
        if ((dx * ax + dz * az) / (d * alen) < 0.1) continue;
        for (let dy = 1; dy >= -1; dy--) {
          const x = base.x + dx, y = base.y + dy, z = base.z + dz;
          if (!this.standable(bot, x, y, z)) continue;
          const open = this.openness(bot, x, y, z);
          const score = -open * 2 - d * 0.6;
          // 掩体是局部直走目标，隔墙的“好格子”只会把身体引到墙上。
          if (score > bestScore && !this.movementSafe(bot, x + 0.5 - me.x, z + 0.5 - me.z, false, d)) continue;
          if (score > bestScore) { bestScore = score; best = { x, y, z }; }
          break;
        }
      }
    }
    if (!best) { this.coverCell = null; return; }
    if (hereOpen - this.openness(bot, best.x, best.y, best.z) < 2) { this.coverCell = null; return; }
    this.coverCell = best;
  }

  private coverArrived(bot: Bot): boolean {
    const c = this.coverCell;
    if (!c) return true;
    const p = bot.entity.position;
    return Math.hypot(p.x - (c.x + 0.5), p.z - (c.z + 0.5)) < 1.0 && Math.abs(p.y - c.y) < 1.2;
  }

  /**
   * 世界方向 → 方向键。局部坐标系是台架量出来钉死的(probe-frame.ts),别照公式推:
   * 符号推反了不报错,只会让人朝反方向走,在战斗数据里表现成「这条战术没用」。
   */
  private pressToward(bot: Bot, dx: number, dz: number, sprint = false): void {
    const len = Math.hypot(dx, dz);
    if (len < 1e-6) return;
    const ux = dx / len, uz = dz / len;
    const y = bot.entity.yaw;
    const f = ux * -Math.sin(y) + uz * -Math.cos(y);
    const l = ux * -Math.cos(y) + uz * Math.sin(y);
    this.movementIntent = this.appliedDirection(bot, dx, dz);
    bot.setControlState('forward', f > 0.35);
    bot.setControlState('back', f < -0.35);
    bot.setControlState('left', l > 0.35);
    bot.setControlState('right', l < -0.35);
    const wantSprint = sprint && f > 0.35 && Date.now() >= this.wtapUntil;
    if (wantSprint && this.sprintSince === 0) this.sprintSince = Date.now();
    if (!wantSprint) this.sprintSince = 0;
    bot.setControlState('sprint', wantSprint);
  }

  private stopMovement(bot: Bot): void {
    this.movementIntent = null;
    for (const key of ['forward', 'back', 'left', 'right', 'sprint', 'jump'] as const) {
      bot.setControlState(key, false);
    }
  }

  /** 前面是一格高的坎就跳上去;水里按住跳=向上游(不按就往下沉,沉到头进水战斗就被防溺水抢走) */
  private autoJump(bot: Bot, dx?: number, dz?: number): void {
    if (this.swingPhase === 'hop') return;
    if (bodyInWater(bot)) { bot.setControlState('jump', true); return; }
    const len = dx === undefined || dz === undefined ? 0 : Math.hypot(dx, dz);
    const ax = len > 1e-6 ? dx! / len : -Math.sin(bot.entity.yaw);
    const az = len > 1e-6 ? dz! / len : -Math.cos(bot.entity.yaw);
    const ahead = bot.entity.position.offset(ax * 0.8, 0, az * 0.8);
    const feet = bot.blockAt(ahead);
    const head = bot.blockAt(ahead.offset(0, 1, 0));
    const blocked = feet?.boundingBox === 'block' && head?.boundingBox !== 'block';
    bot.setControlState('jump', Boolean(blocked) && bot.entity.onGround);
  }

  // —— v7 盾与出手 ————————————————————————————————————————————

  /** 副手已有盾或其他装备时尊重现有选择；空位才补背包中的图腾。 */
  private equipSpareTotem(bot: Bot, now: number): void {
    if (bot.inventory.slots?.[45] || this.offhandEquipping
      || now - this.lastOffhandAttemptAt < OFFHAND_RETRY_MS) return;
    const totem = bot.inventory.items().find((item) => item.name === 'totem_of_undying' && item.count > 0);
    if (!totem) return;
    this.lastOffhandAttemptAt = now;
    this.offhandEquipping = true;
    void bot.equip(totem, 'off-hand').then(() => {
      if (bot.inventory.slots?.[45]?.name !== 'totem_of_undying') return;
      this.opts.diag?.write({ lane: 'combat', event: 'offhand-totem', msg: '副手补上不死图腾' });
      this.opts.emit('副手补上了不死图腾。', false, false);
    }).catch((error: unknown) => {
      this.opts.diag?.write({ lane: 'combat', event: 'offhand-equip-failed', msg: String(error) });
    }).finally(() => { this.offhandEquipping = false; });
  }

  private combatFood(bot: Bot): ReturnType<Bot['inventory']['items']>[number] | null {
    const items = itemsInReach(bot);
    if ((bot.health ?? 20) <= 10) {
      const apple = items.find((item) => item.name === 'golden_apple' && item.count > 0);
      if (apple) return apple;
    }
    if ((bot.food ?? 20) >= 18) return null;
    const foods = (bot.registry.foodsByName ?? {}) as Record<string, { foodPoints?: number } | undefined>;
    return items.filter((item) => item.count > 0 && foods[item.name]
      && !RISKY_FOODS.has(item.name) && item.name !== 'golden_apple'
      && item.name !== 'enchanted_golden_apple')
      .sort((a, b) => (foods[b.name]?.foodPoints ?? 0) - (foods[a.name]?.foodPoints ?? 0))[0] ?? null;
  }

  private cancelCombatFood(bot: Bot): void {
    if (!this.eating) return;
    this.supplyGeneration += 1;
    this.eating = false;
    try { bot.deactivateItem(); } catch { /* consume may already have ended */ }
  }

  /** 只在无近身或远程压制的空档进食；进食期间暂停出手。 */
  private tryCombatFood(bot: Bot, foes: Foe[], now: number): boolean {
    if (this.eating) {
      if (foes.some((foe) => foe.reach < 4)) {
        this.cancelCombatFood(bot);
        this.armMelee(bot);
        return false;
      }
      return true;
    }
    if (this.offhandEquipping || now - this.lastFoodAttemptAt < FOOD_RETRY_MS
      || now - this.lastSelfHurtAt < 2_500
      || foes.some((foe) => foe.reach < 8 || (RANGED.has(foe.name) && foe.flat < 18))) return false;
    const food = this.combatFood(bot);
    if (!food) return false;
    this.lastFoodAttemptAt = now;
    this.eating = true;
    const generation = ++this.supplyGeneration;
    const checkActive = (): void => {
      if (generation !== this.supplyGeneration || this.bot !== bot || this.state === 'idle') {
        throw new SkillBlocked('战斗补食控制权已变化，停止旧换手与消费', [], 'local', 'execution-context-changed');
      }
    };
    this.lowerShield(bot);
    this.opts.ranged?.abort();
    if (this.pathing) {
      this.pathing = false;
      dropOwnedGoal(bot, 'combat', '进食时先停下', this.opts.diag);
    }
    this.stopMovement(bot);
    void (async () => {
      try {
        await equipHandConfirmed(bot, food, checkActive);
        const receipt = await consumeHeldFood(bot, food.name, checkActive);
        if (generation !== this.supplyGeneration) return;
        this.opts.diag?.write({ lane: 'combat', event: 'combat-food', msg: receipt,
          data: { item: food.name, health: bot.health, food: bot.food } });
        this.opts.emit(receipt, false, false);
        this.lastProgressAt = Date.now();
      } catch (error) {
        if (generation === this.supplyGeneration) {
          this.opts.diag?.write({ lane: 'combat', event: 'combat-food-failed', msg: String(error) });
        }
      } finally {
        if (generation === this.supplyGeneration) {
          if (this.state !== 'idle') {
            const weapon = bestWeapon(bot);
            if (weapon) await equipHandConfirmed(bot, weapon, checkActive).catch(() => undefined);
          }
          this.eating = false;
        }
      }
    })();
    return true;
  }

  private raiseShield(bot: Bot): void {
    const off = (bot.inventory.slots[45] as { name?: string } | null)?.name;
    if (off !== 'shield') return;
    try { bot.activateItem(true); this.shieldUp = true; } catch { /* noop */ }
  }

  private lowerShield(bot: Bot): void {
    if (!this.shieldUp) return;
    try { bot.deactivateItem(); } catch { /* noop */ }
    this.shieldUp = false;
  }

  /** 远程怪在射程内且近处没贴脸的就举着;出手前放下(抬起要 5 tick 才生效) */
  private shieldLogic(bot: Bot, foes: Foe[], now: number): void {
    const ranged = foes.some((f) => RANGED.has(f.name) && f.flat < 18);
    const closeMelee = foes.some((f) => !RANGED.has(f.name) && f.reach < 3.2);
    const want = ranged && !closeMelee && now >= this.shieldHoldUntil;
    if (want && !this.shieldUp) this.raiseShield(bot);
    if (!want && this.shieldUp) this.lowerShield(bot);
  }

  private canSwing(now: number): boolean {
    return this.bot !== null && now - this.lastSwingAt >= meleeCooldownMs(this.bot);
  }

  /**
   * 出手。前摇排进冷却窗口(prep,单独值 1.6×):横扫站定 100ms、跳劈起跳约 300ms,
   * 不是冷却好了再准备——提前 lead 毫秒进入前摇,冷却一满正好在暴击/横扫的姿态上。
   */
  private tryOffense(target: Foe, mode: 'crit' | 'kb' | 'sweep', now: number): void {
    const bot = this.bot!;
    if (!this.meleeHandReady(bot, now)) {
      this.swingPhase = 'idle';
      bot.setControlState('jump', false);
      return;
    }
    const inReach = target.reach <= REACH_MAX;
    const cd = meleeCooldownMs(bot);
    const left = cd - (now - this.lastSwingAt);
    const ready = left <= 0;

    if (this.swingPhase === 'hop') {
      const vy = bot.entity.velocity?.y ?? 0;
      if (vy < -0.05 && ready) { bot.setControlState('jump', false); this.swing(bot, target, now); return; }
      if (now > this.phaseUntil) {
        bot.setControlState('jump', false);
        if (ready) this.swing(bot, target, now);
        else this.swingPhase = 'idle';
      }
      return;
    }
    if (this.swingPhase === 'settle') {
      if (now >= this.phaseUntil && ready) { this.swing(bot, target, now); return; }
      if (now > this.phaseUntil + 400) this.swingPhase = 'idle';
      return;
    }
    if (!inReach) return;
    // 隔着方块不出手:打得中也不打(镜头里像开挂),E5 那边同样不算「够得着」
    if (!this.losTo(bot, target)) return;

    const lead = mode === 'crit' ? 300 : 100;
    if (left > lead) return;

    if (mode === 'crit') {
      if (bot.entity.onGround) {
        this.tacticalMove = null;
        bot.setControlState('sprint', false);
        bot.setControlState('jump', true);
        this.swingPhase = 'hop';
        this.phaseTargetId = target.id;
        this.phaseUntil = now + 450 + Math.max(0, lead);
      }
      return;
    }
    if (mode === 'sweep') {
      this.tacticalMove = null;
      for (const k of ['forward', 'back', 'left', 'right', 'sprint'] as const) bot.setControlState(k, false);
      this.movementIntent = null;
      this.swingPhase = 'settle';
      this.phaseTargetId = target.id;
      this.phaseUntil = now + 100;
      return;
    }
    if (!ready) return;
    // kb:命中瞬间要在疾跑;控制状态下一 tick 才发包,先按住攒一 tick 再出手。
    // 攒不出疾跑就别一直攒——冷却空转半秒,软伤害也比不出手强
    // 水里疾跑攒不出来:别为它空转冷却,到点就出手
    const overdue = now - this.lastSwingAt > cd + 500 || bodyInWater(bot);
    if (!overdue && (!bot.controlState.sprint || now - this.sprintSince < 60)) {
      const fx = -Math.sin(bot.entity.yaw), fz = -Math.cos(bot.entity.yaw);
      if (this.movementSafe(bot, fx, fz)) {
        bot.setControlState('forward', true);
        bot.setControlState('sprint', true);
        this.movementIntent = { x: fx, z: fz };
        if (this.sprintSince === 0) this.sprintSince = now;
        return;
      }
    }
    this.swing(bot, target, now);
    this.wtapUntil = now + 120;
  }

  private swing(bot: Bot, target: Foe, now: number): void {
    this.swingPhase = 'idle';
    if (this.shieldUp) { this.lowerShield(bot); this.shieldHoldUntil = now + 250; }
    try { bot.attack(target.ent as never); } catch { /* 实体刚没 */ }
    this.lastSwingAt = now;
    this.swings += 1;
    this.lastSwingTargetId = target.id;
    this.rememberStruck(target.id);
  }

  // —— 撤退与收尾 ————————————————————————————————————————————

  private beginRetreat(why: 'flee' | 'mc_stop' | 'no-fight'): void {
    this.cancelRanged();
    const bot = this.bot;
    if (!bot?.entity) { this.end('gone'); return; }
    if (!this.alive(bot) || (this.active && this.bodyEnded(bot))) { this.end('death'); return; }
    this.cancelCombatFood(bot);
    this.releaseWalkOnly ??= walkOnlyPath(bot);
    if (why === 'flee') this.opts.onLowHealth?.(bot);
    if (!this.alive(bot) || (this.active && this.bodyEnded(bot))) { this.end('death'); return; }
    // 没打起来就直接撤(E7 / 血线挡下):E4 滑窗记的是这一场,起点得是现在,
    // 否则 end() 会把上一场的开始时刻算成本场时长
    if (this.state === 'idle') {
      this.controlSummary = { schemaVersion: 1, finalMode: 'retreating', enteredDesperate: false, retreat: null };
      this.startedAt = Date.now();
      this.lifeEpisodeAtStart = this.life(bot)?.episodeId ?? null;
      this.healthBefore = bot.health ?? null;
      this.sceneBefore = this.observeScene(bot);
      this.sessionStartedAt = this.startedAt;
      this.deadIds.clear();
      this.targetDeaths.clear();
      this.targetDeathsPending.clear();
      this.swings = this.landed = this.arrows = this.rangedLanded = 0;
    }
    this.state = 'retreating';
    this.retreatWhy = why;
    const now = Date.now();
    this.retreatStartedAt = now;
    this.swingPhase = 'idle';
    if (this.pathing) { this.pathing = false; dropOwnedGoal(bot, 'combat', '转撤退', this.opts.diag); }
    this.lowerShield(bot);
    const foes = this.scan(bot, this.opts.tuning(), RETREAT_CLEAR_DIST);
    let cx = 0, cz = 0;
    for (const f of foes) { cx += f.pos.x; cz += f.pos.z; }
    this.retreatFrom = foes.length > 0
      ? { x: cx / foes.length, z: cz / foes.length }
      : { x: bot.entity.position.x + 1, z: bot.entity.position.z };
    this.retreatHits = 0;
    // 触发这场撤退的那次伤害也属于安全时窗；否则第一拍实体表短暂丢失就会立刻收工。
    this.retreatLastHurtAt = now;
    this.retreatSafeSince = 0;
    this.retreatProgressAt = now;
    this.retreatProgressPos = {
      x: bot.entity.position.x, y: bot.entity.position.y, z: bot.entity.position.z,
    };
    this.retreatEscalated = false;
    this.retreatBarehandNoted = false;
    this.retreatEdgeNoted = false;
    // 在水里"拉开 N 格"是永远追不上的目标(溺尸游得比人快),赢法只有出水:目标改成最近的岸
    this.retreatBank = bodyInWater(bot) ? findBankCell(bot, this.retreatFrom, 16) : null;
    this.retreatSamplePosition = null;
    this.controlSummary.retreat = { startedAt: new Date(now).toISOString(), waterAtStart: bodyInWater(bot),
      bankCandidate: this.retreatBank ? { ...this.retreatBank } : null, routeStatus: 'unverified',
      movement: { samples: 0, horizontalActiveSamples: 0, horizontalIntentSamples: 0, jumpOnlySamples: 0,
        observedHorizontalDistance: 0, progressBasis: 'sampled_position_delta', lastRejection: null } };
    this.lastMovementRejection = null;
    if (this.retreatBank) {
      const b = this.retreatBank;
      this.opts.diag?.write({
        lane: 'combat', event: 'retreat-to-bank',
        msg: `在水里撤退:朝 (${b.x}, ${b.y}, ${b.z}) 的登岸点游`,
        data: { bank: b },
      });
    }
  }

  /** 撤退:背对怪群疾跑;距离安全并守住无伤时窗才收,到时仍危险就升级策略 */
  private retreatTick(bot: Bot, now: number): void {
    const from = this.retreatFrom!;
    const p = bot.entity.position;
    const foes = this.scan(bot, this.opts.tuning(), RETREAT_CLEAR_DIST);
    const nearest = foes.reduce((m, f) => Math.min(m, f.flat), 99);
    const last = this.retreatProgressPos;
    if (!last || Math.hypot(p.x - last.x, p.y - last.y, p.z - last.z) >= 1) {
      this.retreatProgressAt = now;
      this.retreatProgressPos = { x: p.x, y: p.y, z: p.z };
    }
    const stalled = now - this.retreatProgressAt >= RETREAT_STALL_MS;
    const recentlyHurt = now - this.retreatLastHurtAt < RETREAT_SAFE_HOLD_MS;
    const inWater = bodyInWater(bot);
    if (this.retreatBank && !inWater) this.retreatBank = null; // 上岸了,剩下按老样子拉开
    // 游向岸比跑步慢:有登岸目标时放宽时限,别在半程收工又被追回水里
    const maxMs = this.retreatBank ? RETREAT_MAX_MS * 2 : RETREAT_MAX_MS;
    const timedOut = now - this.retreatStartedAt >= maxMs;
    const bank = this.retreatBank;
    const wantedX = bank ? bank.x + 0.5 - p.x : p.x - from.x;
    const wantedZ = bank ? bank.z + 0.5 - p.z : p.z - from.z;
    const heading = this.retreatHeading(bot, foes, wantedX, wantedZ);
    if (!bank && !footingAhead(bot, wantedX, wantedZ) && !this.retreatEdgeNoted) {
      this.retreatEdgeNoted = true;
      this.opts.diag?.write({
        lane: 'combat', event: 'retreat-edge',
        msg: `撤退方向前面没有 ${RETREAT_MAX_DROP} 格内的落脚:${heading ? '改走侧面' : '两侧也没有,原地不动'}`,
        data: { at: { x: p.x, y: p.y, z: p.z }, dx: wantedX, dz: wantedZ },
      });
    }
    const trapped = stalled && heading === null;

    // 跑不掉时近战按贴身判据还手；远程目标须持续命中且撤退无进展。
    // RETREAT_MAX_MS 到期只升级撤退策略，不单独触发转身还手。
    const fightable = foes.filter((f) => f.visible && !NO_FIGHT.has(f.name)).sort((a, b) => a.reach - b.reach);
    if (this.retreatWhy !== 'no-fight' && fightable.length > 0) {
      const threat = fightable[0];
      // 刚挨过打且 1.5 秒净位移仍为零，说明“看似可走”的侧路也未让身体脱险。
      // 不再等第二、第三次命中才回身；低血时那往往已经是致命一击。
      const retreatAge = now - this.retreatStartedAt;
      const stuckUnderFire = stalled && retreatAge >= RETREAT_STALL_MS && retreatAge <= 2_500
        && now - this.retreatLastHurtAt <= 2_500 && threat.reach < 10;
      const closeCornered = (this.retreatHits >= 2 || trapped || stuckUnderFire)
        && now - this.retreatStartedAt >= RETREAT_STALL_MS && threat.reach <= 3.2;
      const rangedCornered = (this.retreatHits >= 2 || trapped || stuckUnderFire)
        && (recentlyHurt || stuckUnderFire) && stalled;
      // mc_stop 请求先脱战；贴身连续受击证明没脱开时仍需自卫。
      // 远处火力下的 mc_stop 继续找退路，避免把“停战”变成主动追击远程怪。
      if (closeCornered || (this.retreatWhy === 'flee' && rangedCornered)) {
        if (this.turnAndFight(bot, threat, now, closeCornered ? 'close' : 'stalled')) return;
      }
    }

    // 撤退证伪的另一面:跑不动、也没人打。这不是把撤退记成成功 —— 是它已经证明
    // 自己什么都挡不住,身体该还给任务;再挨打 `onHurtBy` 照常重开这一场。
    if (timedOut && stalled && now - this.retreatLastHurtAt >= RETREAT_IDLE_MS) {
      this.opts.emit(
        `跑不动,也没人打我——${nearest < 99 ? `最近的还在 ${Math.round(nearest)} 格外` : '附近也没怪了'},先把手还回去。(生命 ${this.hp()}/20)`,
        true, false,
      );
      this.opts.diag?.write({
        lane: 'combat', event: 'retreat-idle',
        msg: `撤退 ${Math.round((now - this.retreatStartedAt) / 1000)}s 无位移且 ` +
          `${Math.round((now - this.retreatLastHurtAt) / 1000)}s 无伤:收工,最近威胁 ${Math.round(nearest * 10) / 10} 格`,
        data: { nearest, hits: this.retreatHits, why: this.retreatWhy },
      });
      this.end('stuck');
      return;
    }

    // 计时只触发策略升级。打不过的目标和明确 mc_stop 不强行改成反击，但也不能
    // 把威胁还在附近的状态写成成功；继续持有撤退身体并只记一次升级事实。
    if (timedOut && nearest <= RETREAT_CLEAR_DIST && !this.retreatEscalated) {
      this.retreatEscalated = true;
      this.opts.diag?.write({
        lane: 'combat', event: 'retreat-extended',
        msg: `撤退到时仍不安全:最近威胁 ${Math.round(nearest * 10) / 10} 格,继续撤`,
        data: { nearest, hits: this.retreatHits, stalled, why: this.retreatWhy },
      });
    }

    const distanceSafe = nearest > RETREAT_CLEAR_DIST && !inWater;
    if (distanceSafe) {
      if (this.retreatSafeSince === 0) this.retreatSafeSince = now;
    } else {
      this.retreatSafeSince = 0;
    }
    if (
      distanceSafe &&
      now - this.retreatSafeSince >= RETREAT_SAFE_HOLD_MS &&
      now - this.retreatLastHurtAt >= RETREAT_SAFE_HOLD_MS
    ) {
      const doneWhy = this.retreatWhy;
      this.opts.emit(
        doneWhy === 'flee'
          ? `跑开了,喘口气。生命 ${this.hp()}/20。`
          : `撤出来了。生命 ${this.hp()}/20。`,
        false, false,
      );
      this.end(doneWhy === 'mc_stop' ? 'mc_stop' : 'flee');
      return;
    }
    if (!heading) {
      this.stopMovement(bot);
      const threat = fightable[0];
      if (threat) void bot.lookAt(threat.pos.offset(0, EYE, 0), true).catch(() => undefined);
      return;
    }
    void bot.lookAt(new Vec3(p.x + heading.x * 4, p.y + EYE, p.z + heading.z * 4), true).catch(() => undefined);
    if (!this.movementSafe(bot, heading.x, heading.z, false, 2.1)) { this.stopMovement(bot); return; }
    this.pressToward(bot, heading.x, heading.z, true);
    this.autoJump(bot, heading.x, heading.z);
  }

  /** 从可站立方向中选撤退路线；直线后退被墙挡住时优先沿墙侧移。 */
  private retreatHeading(bot: Bot, foes: Foe[], dx: number, dz: number): { x: number; z: number } | null {
    const p = bot.entity.position;
    const len = Math.hypot(dx, dz);
    if (len < 1e-6) return null;
    const ux = dx / len, uz = dz / len;
    let best: { x: number; z: number } | null = null;
    let bestScore = -Infinity;
    for (let i = 0; i < 16; i++) {
      const d = slotDir(i);
      if (!this.movementSafe(bot, d.x, d.z, false, 2.1)) continue;
      const alignment = d.x * ux + d.z * uz;
      // 退路可侧移，但不能为了绕墙主动穿过贴身的怪。
      const nearby = foes.filter((f) => f.flat < 5);
      const foePenalty = nearby.reduce((sum, f) => {
        const vx = f.pos.x - p.x, vz = f.pos.z - p.z;
        return sum + Math.max(0, (d.x * vx + d.z * vz) / (Math.hypot(vx, vz) || 1)) * 0.8;
      }, 0);
      const score = alignment - foePenalty;
      if (score > bestScore) { bestScore = score; best = d; }
    }
    return best;
  }

  /**
   * 撤退失败后转身还手，重新选择武器；本场不再检查 E2 和普通入场血线，
   * E1/E3/E5/E8 仍生效。无近战武器、无可用远程且低于 fleeHealth + ENGAGE_MARGIN
   * 时返回 false 并继续撤退。
   */
  private turnAndFight(bot: Bot, glued: Foe, now: number, cause: 'close' | 'stalled'): boolean {
    // A failed bow/equip is not evidence that punching with the previous food
    // item is a usable fallback. Keep the escape owner until it can disengage.
    if (!bestWeapon(bot) && this.rangedUnavailable) return false;
    if (this.meleeEquip?.failed && !this.rangedReady(bot)) return false;
    const line = this.opts.tuning().fleeHealth + ENGAGE_MARGIN;
    if (!bestWeapon(bot) && !this.rangedReady(bot) && (bot.health ?? 20) < line) {
      if (!this.retreatBarehandNoted) {
        this.retreatBarehandNoted = true;
        this.opts.diag?.write({
          lane: 'combat', event: 'cornered-barehand',
          msg: `撤退受阻(${cause})但空手、生命 ${this.hp()}/20 低于 ${line}:不转身还手,继续撤`,
          data: { cause, hits: this.retreatHits, foe: glued.name, distance: glued.flat, health: bot.health, line },
        });
      }
      return false;
    }
    this.controlSummary.enteredDesperate = true;
    this.desperate = true;
    this.state = 'fighting';
    this.retreatBank = null;
    this.deadlineAt = now + this.opts.tuning().maxSec * 1000;
    this.lastProgressAt = now;
    this.lastRealProgressAt = now;
    this.lastLandedAt = now;
    this.lastStatusAt = now;
    this.emptySince = 0;
    this.swingPhase = 'idle';
    this.targetId = glued.id;
    this.hybridWeapon = 'melee';
    this.rangedOwner = {};
    this.rangedPendingOwner = null;
    this.nextRangedAt = now;
    const held = this.armMelee(bot);
    const pressure = glued.reach <= 3.2 ? '还咬着我' : '还在远处压着我';
    this.opts.emit(`跑不掉,${zhEntity(glued.name)}${pressure}——回头打!(生命 ${this.hp()}/20${held})`, true, true);
    this.opts.diag?.write({
      lane: 'combat', event: 'cornered',
      msg: `撤退失败(${cause}):挨了 ${this.retreatHits} 下,${glued.name}在 ${Math.round(glued.flat * 10) / 10} 格:转身还手,生命 ${this.hp()}/20`,
      data: { cause, hits: this.retreatHits, foe: glued.name, distance: glued.flat, health: bot.health },
    });
    return true;
  }

  /**
   * 环境自保夺权(岩浆/溺水):立刻放开身体,静默收工——由环境反射自己汇报,
   * 战斗这边不抢话。优先级 ENV > FIGHT > TASK 里的那一道。
   */
  yieldToEnv(): void {
    if (this.state !== 'idle') this.end('env');
  }

  /**
   * `queue:"now"` 夺手:她说的「现在」就是现在,战斗也放下。
   *
   * 与 `mc_stop` 的收手分得开:那一条要撤退,而撤退期间身体仍归战斗,新任务照样
   * 跑不起来;这一条当场把身体交还,任务立刻开跑。交还后留一小段不自动进场的宽限
   * —— 250ms 巡检会在下一拍把刚开跑的任务重新挂起,那就等于什么都没改。挨打仍走
   * `onHurtBy`(宽限期内它退回反射的降级行为),环境反射照旧在两者之上。
   *
   * 首步为 eat/flee/surface 时允许交还低血自保；环境危机仍由环境反射持有。
   * 返回刚才在做什么；本来就空闲返回 null。
   */
  standDown(firstStep?: SkillCall): string | null {
    if (this.state === 'idle') return null;
    if (this.bot && this.bodyEnded(this.bot)) { this.end('death'); return null; }
    // queue:"now" 只更新普通任务意图，不清除受击和无进展记录。
    // 低血、绝境战斗或刚受击的撤退只向进食和撤离交还身体。
    const now = Date.now();
    const retreatStillSaving = this.state === 'retreating' && now - this.retreatLastHurtAt < RETREAT_IDLE_MS;
    const survival = firstStep?.skill === 'eat' || firstStep?.skill === 'flee' || firstStep?.skill === 'surface';
    const environment = this.opts.envBusy();
    if (environment || (!survival
      && (retreatStillSaving || this.desperate || (this.bot?.health ?? 0) < this.opts.tuning().fleeHealth))) {
      this.opts.diag?.write({
        lane: 'combat', event: 'stand-down-deferred',
        msg: `queue:"now" 未夺走救命动作:${environment ? '环境自保' : retreatStillSaving ? '撤退中刚挨过打' : `生命 ${this.hp()}/20`}`,
        data: { state: this.state, health: this.bot?.health, hits: this.retreatHits },
      });
      return null;
    }
    const what = '正在跟怪打';
    this.cooldownUntil = Date.now() + STAND_DOWN_GRACE_MS;
    this.opts.diag?.write({
      lane: 'combat', event: 'stand-down',
      msg: `queue:"now" 夺手:${what},当场交还身体,${STAND_DOWN_GRACE_MS / 1000}s 内不自动进场`,
      data: { was: this.state, graceMs: STAND_DOWN_GRACE_MS, firstStep, survival },
    });
    this.opts.emit('先不打了,这件事更急。', false, false);
    this.end('preempt');
    return what;
  }

  /** mc_stop:收手 + 撤退(原地站住等于送死)。返回给工具回执的一句话 */
  requestStop(): string | null {
    if (this.state === 'idle') return null;
    if (this.bot && this.bodyEnded(this.bot)) { this.end('death'); return null; }
    if (this.state === 'retreating') return '正在撤了';
    this.beginRetreat('mc_stop');
    return '收手了,正在撤离';
  }

  private endClear(): void {
    if (this.bot && this.bodyEnded(this.bot)) { this.end('death'); return; }
    const totalDeaths = [...this.targetDeaths.values()].reduce((a, b) => a + b, 0);
    const what = totalDeaths > 0
      ? `打完了,观察到 ${[...this.targetDeaths].map(([n, c]) => `${zhEntity(n)}${c > 1 ? `×${c}` : ''}`).join('、')}死亡，未确认本人击杀归属。`
      : '当前已无可见交战目标，未确认目标死亡。';
    this.opts.emit(
      `${what}刀 ${this.swings} 次命中 ${this.meleeLanded()} 次,` +
        `箭 ${this.arrows} 支命中 ${this.rangedLanded} 次;生命 ${this.hp()}/20。`,
      true,
      false,
    );
    this.end('clear');
  }

  private busyRatioNow(): number {
    const now = Date.now();
    const from = now - BUSY_WINDOW_MS;
    while (this.busyLog.length > 0 && this.busyLog[0].to < from) this.busyLog.shift();
    let busy = 0;
    for (const b of this.busyLog) busy += Math.min(b.to, now) - Math.max(b.from, from);
    return busy / BUSY_WINDOW_MS;
  }

  private observeScene(bot: Bot): CombatScene {
    const p = bot.entity.position;
    const nearbyHostiles: Record<string, number> = {};
    for (const e of Object.values(bot.entities ?? {})) {
      if (!e?.position || e.isValid === false || !HOSTILE.has(e.name ?? '')
        || Math.hypot(e.position.x - p.x, e.position.y - p.y, e.position.z - p.z) > 16) continue;
      nearbyHostiles[e.name!] = (nearbyHostiles[e.name!] ?? 0) + 1;
    }
    return { dimension: bot.game?.dimension ?? null, position: { x: p.x, y: p.y, z: p.z }, loadout: combatLoadout(bot),
      hostileRadius: 16, nearbyHostiles, equipment: { mainHand: bot.heldItem?.name ?? null,
        offHand: bot.inventory?.slots?.[45]?.name ?? null,
        helmet: bot.inventory?.slots?.[5]?.name ?? null, chestplate: bot.inventory?.slots?.[6]?.name ?? null,
        leggings: bot.inventory?.slots?.[7]?.name ?? null, boots: bot.inventory?.slots?.[8]?.name ?? null } };
  }

  private end(reason: EndReason): void {
    if (this.state === 'idle') return;
    if (this.bot && this.bodyEnded(this.bot)) reason = 'death';
    this.cancelRanged();
    const bot = this.bot;
    if (bot) this.cancelCombatFood(bot);
    const controlSummary = structuredClone({ ...this.controlSummary, finalMode: this.state });
    const lifecycle = bot ? this.life(bot) : undefined;
    const deathEpisodeId = reason === 'death' && lifecycle?.episodeId && lifecycle.episodeId !== this.lifeEpisodeAtStart
      && Date.parse(lifecycle.observedAt) >= this.startedAt ? lifecycle.episodeId : undefined;
    this.state = 'idle';
    this.meleeEquip = null;
    this.trackingLease = null;
    this.desperate = false;
    this.retreatBank = null;
    this.unhook();
    this.releaseWalkOnly?.();
    this.releaseWalkOnly = null;
    if (bot?.entity) {
      this.release(bot);
      // 统一交还身体；releaseBody 保留反射登记的逃生目标。
      releaseBody(bot, `战斗收工(${reason})`, this.opts.diag, 'combat');
    }
    this.pathing = false;
    this.busyLog.push({ from: this.startedAt, to: Date.now() });
    this.provoked.clear();
    // 够不着收工的怪下一拍还在圈里:不设冷却就是 1 秒一开(见 STUCK_COOLDOWN_MS)
    if (reason === 'stuck') this.cooldownUntil = Math.max(this.cooldownUntil, Date.now() + STUCK_COOLDOWN_MS);
    this.opts.diag?.write({
      lane: 'combat', event: 'end',
      msg: `收工(${reason}),${Math.round((Date.now() - this.startedAt) / 1000)}s,` +
        `观察到交战目标死亡 ${[...this.targetDeaths.values()].reduce((a, b) => a + b, 0)}，本人击杀归属未知,` +
        `挥刀 ${this.swings} 次命中 ${this.meleeLanded()} 次,` +
        `放箭 ${this.arrows} 支命中 ${this.rangedLanded} 次,生命 ${reason === 'death' ? 0 : this.hp()}/20`,
      data: {
        reason, ms: Date.now() - this.startedAt, kills: null, killAttribution: 'unavailable', targetDeaths: Object.fromEntries(this.targetDeaths),
        swings: this.swings, arrows: this.arrows, meleeLanded: this.meleeLanded(),
        rangedLanded: this.rangedLanded, landed: this.landed,
      },
    });
    this.opts.report?.({ startedAt: new Date(this.startedAt).toISOString(),
      endedAt: new Date(Date.now()).toISOString(), reason,
      healthBefore: this.healthBefore, healthAfter: reason === 'death' ? 0 : bot?.health ?? null,
      sceneBefore: this.sceneBefore, controlSummary, ...(deathEpisodeId ? { deathEpisodeId } : {}),
      kills: null, killAttribution: 'unavailable', targetDeaths: Object.fromEntries(this.targetDeaths), swings: this.swings,
      meleeLanded: this.meleeLanded(), arrows: this.arrows, rangedLanded: this.rangedLanded });
    // 只有正常战斗收尾解冻断点。断线、环境夺权、外部抢占与死亡各自由其终态边界
    // 处理冻结队列；在这里泵回会让任务进入已断线或正在交权的执行器。
    const resumable = reason === 'clear' || reason === 'flee' || reason === 'timeout' ||
      reason === 'stuck' || reason === 'mc_stop' || reason === 'busy';
    const resumed = resumable ? this.opts.resumeTasks() : null;
    if (resumed) {
      this.opts.emit(`${resumed}。`, false, false);
    }
  }

  private trackTick(bot: Bot, now: number): void {
    const lease = this.trackingLease, entity = lease ? bot.entities[lease.targetId] : null;
    if (!lease || now >= lease.expiresAt || !entity?.isValid || !entity.position
      || (entity.uuid ?? null) !== lease.uuid || !canSeeEntity(bot, entity)
      || !this.scan(bot, this.opts.tuning(), 24).some(f => f.id === lease.targetId && f.visible)) {
      this.trackingLease = null; this.end('clear'); return;
    }
    if ((bot.health ?? 0) < this.opts.tuning().fleeHealth) { this.trackingLease = null; this.beginRetreat('flee'); return; }
    const delta = entity.position.minus(bot.entity.position), distance = Math.hypot(delta.x, delta.z);
    if (distance < .01) { this.stopMovement(bot); return; }
    const toward = distance > lease.maxDistance ? 1 : distance < lease.minDistance ? -1 : 0;
    // Maintain the selected range on each physics tick; never chase through unseen terrain or a cliff.
    if (!toward) { this.stopMovement(bot); return; }
    const dx = delta.x / distance * toward, dz = delta.z / distance * toward;
    const to = bot.entity.position.offset(dx * 1.2, 0, dz * 1.2);
    if (!corridorSafe(bot, bot.entity.position, to)) { this.stopMovement(bot); return; }
    this.pressToward(bot, dx, dz, false);
  }

  private release(bot: Bot): void {
    this.tacticalMove = null;
    this.movementIntent = null;
    // sneak 也在名单里:寻路器交互放置失败时是**故意**留着它的
    // (index.js:557-566 只在放成那一支才 sneak=false),战斗夺手正好夹在中间,
    // 于是"战后一直半蹲着走"的残留没人收
    for (const k of ['forward', 'back', 'left', 'right', 'sprint', 'jump', 'sneak'] as const) {
      bot.setControlState(k, false);
    }
    this.lowerShield(bot);
  }

  private cancelRanged(): void {
    this.rangedOwner = null;
    this.rangedPendingOwner = null;
    this.hybridWeapon = 'melee';
    this.opts.ranged?.abort();
  }
}
