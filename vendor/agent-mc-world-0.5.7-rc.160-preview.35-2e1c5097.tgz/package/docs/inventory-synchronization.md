# 背包同步与恢复

`mc_bag`、物资查询和现场读数现在区分五种未确认原因：首次背包数据未到、容器玩家槽位不完整、上一笔操作待确认、上一笔操作结果未知、原生数据包解析失败。不会把后面几种情况都说成“清单还没到”，也不会把未确认的数据说成空背包或物品丢失。

## 确认规则

- 一次物品操作只发送一次。操作完成需要服务器实际槽位及光标确认。
- 完整容器快照，或最后一个缺失玩家槽位到达后，可以恢复清单。空槽也必须实际收到；重复事件不增加覆盖数。
- 关闭窗口、重用窗口编号、重新连接不会继承旧窗口的数据覆盖。迟到的已关闭窗口快照会被丢弃。
- `bot.closeWindow()`、容器的 `close()` 和服务器主动关闭窗口均保留未收到的玩家槽位，不把缺失数据写成空格。容器里实际收到的玩家槽位也供随身清单查询。
- 超时仍返回“结果未知”，不报告成功、不自动重放。收到超时之后新的完整服务器快照（包括光标）才恢复后续物品操作。
- Mineflayer 4.37.1 在点击合成输入槽后会等待产物槽改变。服务器拒绝操作时，产物可能一直不变。已发送的单次点击只剩被动等待，不应因此永远锁住后续读数；新完整快照可解除隔离。尚未发送的延迟点击仍须先结束，防止旧动作在恢复后才突然发出。

## 遇到结果未知时

先停下存取和合成，重新查询背包、打开的容器及光标。支持主动刷新库存的服务器可用其明确提供的刷新命令；框架不会猜测服务器命令。持续未恢复时重新连接，查询实际数量后再决定下一步。不要直接重复上一笔存取、交付或合成。

千灯纪当前提供 `/mycli inventory status`（只读服务器清单）及 `/mycli inventory refresh`（重发本人原版库存数据，不移动物品）。这不是其他服务器默认支持的接口。

## 更新与验证

修复位于 `agent-mc-world` 客户端核心，Paper 重启不能替代远端 Agent 更新。宿主需更新其实际使用的包并重启该 Agent；保留原账号、环境变量、任务及存档。源码更新不代表正在运行的 Agent 已更新。

在包目录运行：

```sh
pnpm install --frozen-lockfile
pnpm test
pnpm typecheck
pnpm build:engine
pnpm pack
```

包含查看器的发行包应沿原锁定资源构建，不能把 engine-only 包当作含完整 Web 资源的替代品。`tests/inventory-sync-recovery.test.ts` 使用锁定版本的真实 Mineflayer 库存插件，覆盖部分/完整数据、空槽、重复/迟到事件、窗口编号重用、三种关窗路径、合成超时、未发送延迟点击和准确提示；装备测试继续验证槽位、光标和服务器拒绝后的停止行为。
## Native item component decoding

For Java 1.21.1, `usingConvertsTo` is boolean-prefixed optional Slot data,
food effects contain full effect instances (including hidden effects), and inline
armor trim materials contain `itemModelIndex: f32` plus VarInt override keys.
The pinned minecraft-data 3.117.0 definitions incorrectly reuse newer layouts.
Corrections are installed before PLAY codec compilation, shared by SDK/MCP/hosts.
1.21.2–1.21.3 retain the float but use string override keys; 1.21.4 removes it.

Reference implementations:
- [MCProtocolLib 1.21 ItemCodecHelper](https://github.com/GeyserMC/MCProtocolLib/blob/1.21-1/protocol/src/main/java/org/geysermc/mcprotocollib/protocol/data/game/item/component/ItemCodecHelper.java)
- [ViaVersion versioned trim codecs](https://github.com/ViaVersion/ViaVersion/blob/master/api/src/main/java/com/viaversion/viaversion/api/minecraft/item/data/trim/ArmorTrimMaterial1_20_5.java)
- [ViaVersion 1.21 optional item definition](https://github.com/ViaVersion/ViaVersion/blob/5.0.5/api/src/main/java/com/viaversion/viaversion/api/type/types/version/Types1_21.java)

`inventorySync.phase=decode_failed` means a complete framed player-window `window_items`
or `set_slot` packet could not be decoded. It is not an empty inventory or an ordinary
initial wait. The diagnostic includes packet kind, byte count, time and error class,
without retaining raw private item payloads. A successfully decoded complete player
window snapshot clears it. One slot update or an unrelated container does not.
The guard also refuses a packet the decoder only partially consumed, which upstream
would otherwise log and still deliver. Existing mutation/cursor confirmation remains.

`tests/item-component-wire.test.ts` constructs independent wire fixtures, feeds the
actual protocol decoder and Mineflayer inventory plugin, and verifies later weapon,
shield and component alignment. These are offline compatibility checks, not proof
that a particular production inventory has recovered.

### Authentication and death are separate boundaries

A login proxy can send zero health before authentication and then spawn a living
player without a `respawn` packet. It must not create a game death episode: doing
so leaves `inventorySynced=false` even after a complete native inventory arrived.
The connection's authentication readiness gates creation of death episodes only;
real death recovery still requires fresh inventory after native respawn. Fresh
authenticated zero-health packets also trigger recovery when Mineflayer already
used its `death` edge for the login lobby. Do not resolve this state by trusting
cached items, clearing real death records, or setting the inventory flag blindly.
