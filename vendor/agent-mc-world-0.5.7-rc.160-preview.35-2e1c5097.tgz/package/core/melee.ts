/**
 * 动手那几下:挑兵器、够不够得着、挥击与冷却、远程接管的判据,以及附近敌对生物的读数。
 *
 * attack 技能与自保反射共用这一层;谁占着身体不在这里决定。
 */
import { piglinIsHostile } from './piglin.ts';
import { sleep, type TaskAttackLease } from './skill-context.ts';
import { canSeeEntity, headInWater } from './terrain.ts';
import {
  HYBRID_MELEE_AT, HYBRID_RANGED_AT, KITE_MAX_RANGE, KITE_MIN_RANGE, bestRangedWeapon, hasRangedLos, hasUsableArrows,
  type BowShotResult, type RangedTarget,
} from './ranged.ts';
import { type AttackMode } from './skills.ts';
import type { Bot } from 'mineflayer';
import { Vec3 } from 'vec3';
import pathfinderPkg from 'mineflayer-pathfinder';
import { Aborted, SkillBlocked, SkillNoop, checkAbort, type SkillContext } from './skill-context.ts';
import { equipHandConfirmed } from './equipment.ts';
import { isKnownTarget } from './entity-facts.ts';
import { dropGoal, findEntity, gotoGoal, levelTravelGoal, walkOnlyPath } from './travel.ts';
import { zhEntity } from './names.ts';
import { chooseHybridWeapon, type HybridWeapon } from './ranged.ts';
import { zhErrorText } from './receipt.ts';
import { itemsInReach } from './inventory.ts';
import { inventoryReadConfirmed } from './inventory-window-sync.ts';
import type { AttackEvidence } from '../src/contracts/attack-evidence.ts';
import { readDurability } from './item-facts.ts';
import { weaponScore } from './weapon-capabilities.ts';
export { weaponScore, WEAPON_KIND_SCORE, WEAPON_TIER_SCORE } from './weapon-capabilities.ts';

const { goals } = pathfinderPkg;

export type HurtSource = Parameters<Bot['attack']>[0];

/** entityHurt 不带 source 时(旧协议路径)回退猜攻击者的距离上限,沿用旧判据的 6 格 */
export const REFLEX_HURT_FALLBACK_RANGE = 6;

/** Unattributed projectile damage can come from archers well outside melee range. */
export const REFLEX_RANGED_HURT_RANGE = 20;
const RANGED_HOSTILE = new Set(['skeleton', 'stray', 'bogged', 'pillager', 'witch',
  'blaze', 'ghast', 'illusioner', 'breeze']);

/** Candidate only: the protocol did not prove which distant mob fired. */
export function nearestRangedHostileWithin(bot: Bot, radius: number): HurtSource | null {
  let best: HurtSource | null = null;
  let bestD = radius;
  for (const entity of Object.values(bot.entities)) {
    if (!entity?.position || entity.isValid === false || entity === bot.entity ||
        !RANGED_HOSTILE.has(entity.name ?? '') ||
        Math.abs(entity.position.y - bot.entity.position.y) > 6) continue;
    const distance = entity.position.distanceTo(bot.entity.position);
    if (distance < bestD) { bestD = distance; best = entity as HurtSource; }
  }
  return best;
}

/** 半径内最近的敌对生物；排除玩家和自身，没有则返回 null。 */
export function nearestHostileWithin(bot: Bot, radius: number): HurtSource | null {
  let best: HurtSource | null = null;
  let bestD = radius;
  for (const id of Object.keys(bot.entities)) {
    const e = bot.entities[id as unknown as number];
    if (!e?.position || e.type === 'player' || e === bot.entity) continue;
    const name = e.name ?? '';
    if (!HOSTILE.has(name) && !(name === 'piglin' && piglinIsHostile(bot, e))) continue;
    const d = e.position.distanceTo(bot.entity.position);
    if (d < bestD) { bestD = d; best = e as unknown as HurtSource; }
  }
  return best;
}

/** 剑 1.6 攻速 → 满伤间隔 625ms;冷却不满就挥是软伤害。战斗会话与技能共用一份 */
export function meleeCooldownMs(bot: Bot): number {
  return attackCooldownMs(bot);
}

export function meleeWeapons(bot: Bot): ReturnType<Bot['inventory']['items']> {
  return itemsInReach(bot).filter(item => (item.count ?? 1) > 0 && weaponScore(item.name) >= 0
    && (readDurability(item)?.left ?? 1) > 0);
}

export function bestWeapon(bot: Bot, order: readonly string[] = []): ReturnType<Bot['inventory']['items']>[number] | null {
  const items = meleeWeapons(bot);
  for (const name of order) {
    const preferred = items.find(item => item.name === name);
    if (preferred) return preferred;
  }
  let best: ReturnType<Bot['inventory']['items']>[number] | null = null;
  let score = -1;
  for (const item of items) {
    const s = weaponScore(item.name);
    if (s > score) { score = s; best = item; }
  }
  return best;
}

/** 1.9+ 攻速换算的满伤间隔。剑 1.6、斧 1.0,不满就挥是软伤害。 */
export function attackCooldownMs(bot: Bot): number {
  const name = bot.heldItem?.name ?? '';
  if (name.endsWith('_sword')) return 625;
  if (name.endsWith('_axe')) return 1_000;
  if (name === 'trident' || name.endsWith('_trident')) return 900;
  if (name === 'mace') return 1_667;
  if (name.endsWith('_pickaxe')) return 850;
  if (name.endsWith('_shovel') || name.endsWith('_hoe')) return 1_000;
  return 250;
}

export const MELEE_REACH = 3.2;
export const MELEE_CHASE = 8;
export const HOP_MS = 280;
export const STRAFE_MS = 400;

export function releaseMelee(bot: Bot): void {
  for (const k of ['forward', 'back', 'left', 'right', 'sprint', 'jump'] as const) {
    bot.setControlState(k, false);
  }
}

export async function aimAt(bot: Bot, entity: { position: { offset(x: number, y: number, z: number): unknown }; height?: number }): Promise<void> {
  await bot.lookAt(entity.position.offset(0, entity.height ?? 1.6, 0) as never, true);
}

/**
 * 跳劈:落地才跳,下落才出手。冲刺中 crit 不成,先松 sprint。
 * 等不到下落(测试假实体没有速度)就 HOP_MS 后挥,不堵死循环。
 */
export async function hopCrit(bot: Bot): Promise<void> {
  if ((bot.entity as { isInWater?: boolean }).isInWater) return;
  if (bot.entity.onGround === false) return;
  bot.setControlState('sprint', false);
  bot.setControlState('jump', true);
  const deadline = Date.now() + HOP_MS;
  while (Date.now() < deadline) {
    await sleep(50);
    const vy = (bot.entity as { velocity?: { y?: number } }).velocity?.y;
    if (typeof vy === 'number' && vy < 0) break;
  }
  bot.setControlState('jump', false);
}

export function pressMelee(bot: Bot, entity: { position: { distanceTo(o: unknown): number }; name?: string }, strafeLeft: boolean | null): void {
  const d = entity.position.distanceTo(bot.entity.position);
  if (entity.name === 'creeper' && d < 3) {
    bot.setControlState('forward', false);
    bot.setControlState('back', true);
    bot.setControlState('sprint', false);
  } else {
    bot.setControlState('back', false);
    bot.setControlState('forward', d > 1.6);
    bot.setControlState('sprint', d > 2.4);
  }
  bot.setControlState('left', strafeLeft === true);
  bot.setControlState('right', strafeLeft === false);
}

export async function meleeSwing(
  bot: Bot,
  entity: Parameters<Bot['attack']>[0],
  beforeAttack?: () => void,
): Promise<void> {
  await hopCrit(bot);
  await aimAt(bot, entity);
  beforeAttack?.();
  bot.attack(entity);
}

/** 水下攻击回执附氧气读数，不额外用氧气阈值阻断主动攻击。 */
export function underwaterOxygenNote(bot: Bot): string {
  if (!headInWater(bot)) return '';
  return `;人在水下,氧气 ${Math.max(0, Math.min(20, bot.oxygenLevel ?? 20))}/20`;
}

export function rangedTargetOf(entity: NonNullable<Bot['entities'][string]>): RangedTarget {
  return {
    id: entity.id,
    ...(typeof entity.uuid === 'string' ? { uuid: entity.uuid } : {}),
    position: entity.position,
    ...(entity.height === undefined ? {} : { height: entity.height }),
    ...(entity.width === undefined ? {} : { width: entity.width }),
  };
}

export function forcedRangedIssue(bot: Bot, target: RangedTarget): string | null {
  if (!bestRangedWeapon(bot)) return '包里没有可用的弓';
  if (!hasUsableArrows(bot)) return '包里没有普通箭';
  if (!hasRangedLos(bot, target)) return '目标被方块挡住,没有射线';
  return null;
}

export function rangedBlockedText(result: Exclude<BowShotResult, { kind: 'released' }>): string {
  if (result.reason === 'no_arrow') return '普通箭用完了';
  if (result.reason === 'no_los') return '目标被方块挡住,没有射线';
  if (result.reason === 'no_solution') return '这段距离没有可用的弓箭弹道';
  if (result.reason === 'too_close') return '目标贴得太近,弓拉不开安全距离';
  if (result.cause === 'bow_lost') return '可用的弓不在手边了';
  if (result.cause === 'bot_lost') return '连接断了';
  if (result.cause === 'target_lost') return '目标离开视野了';
  return '这一箭在放出前被取消了';
}

export function attackStats(stats: TaskAttackLease): string {
  return `挥击 ${stats.swings} 次命中 ${stats.meleeHits} 次,放箭 ${stats.arrows} 支命中 ${stats.rangedHits} 支` +
    `${stats.hurts > 0 ? `,期间挨打 ${stats.hurts} 次` : ''}`;
}

export function pressRanged(
  bot: Bot,
  distance: number,
  mode: AttackMode,
  strafeLeft: boolean,
): void {
  const kite = mode === 'kite';
  const retreat = distance <= HYBRID_MELEE_AT || (kite && distance < KITE_MIN_RANGE);
  bot.setControlState('jump', false);
  bot.setControlState('forward', kite && distance > KITE_MAX_RANGE);
  bot.setControlState('back', retreat);
  bot.setControlState('sprint', kite && distance > KITE_MAX_RANGE);
  const lateral = kite && distance >= KITE_MIN_RANGE && distance <= KITE_MAX_RANGE;
  bot.setControlState('left', lateral && strafeLeft);
  bot.setControlState('right', lateral && !strafeLeft);
}

/** 一只在 32 格内的敌对生物读数 */
export interface HostileRead {
  e: NonNullable<Bot['entities'][string]>;
  d: number;
}

/** 32 格内所有敌对生物,由近到远。piglin 只在真敌对时算数(见 piglinIsHostile) */
export function hostilesAround(bot: Bot, from: { x: number; y: number; z: number }): HostileRead[] {
  const out: HostileRead[] = [];
  for (const id of Object.keys(bot.entities)) {
    const e = bot.entities[id];
    if (!e?.position || !e.name) continue;
    if (!HOSTILE.has(e.name) && !(e.name === 'piglin' && piglinIsHostile(bot, e))) continue;
    const d = e.position.distanceTo(from as never);
    if (d <= 32) out.push({ e, d });
  }
  return out.sort((a, b) => a.d - b.d);
}

export function nearestHostileTo(bot: Bot, from: { x: number; y: number; z: number }): HostileRead | null {
  return hostilesAround(bot, from)[0] ?? null;
}

export const HOSTILE = new Set([
  'zombie', 'skeleton', 'creeper', 'spider', 'cave_spider', 'enderman', 'witch',
  'slime', 'phantom', 'drowned', 'husk', 'stray', 'pillager', 'vindicator',
  'ravager', 'vex', 'evoker', 'silverfish', 'zombie_villager', 'blaze', 'ghast',
  'magma_cube', 'wither_skeleton', 'warden', 'bogged', 'breeze',
  'piglin_brute', 'hoglin', 'zoglin', 'endermite', 'illusioner', 'guardian',
]);

/**
 * 找目标半径放宽的几种。末地主岛十根黑曜石柱围成半径约 42 的圈,柱高到 100 多格:
 * 对面柱顶的水晶水平 84 格、高差 60 格上下,直线约 110 格;龙绕柱飞同一个范围。
 * 实际看得到多远由服务端的实体下发距离决定(Paper 的 entity-tracking-range.other 默认 64)。
 */
const FAR_TARGETS: Record<string, number> = { end_crystal: 128, ender_dragon: 128 };

export function attackTargetRadius(target: string): number { return FAR_TARGETS[target.toLowerCase()] ?? 32; }

/**
 * 末影水晶不是活物,打掉时只有移除包,没有死亡状态;服务端紧接着在它的坐标上炸一次,
 * 爆炸包只发给 64 格内的玩家。爆心就是水晶坐标,0.5 格只容浮点误差。
 */
const CRYSTAL_BLAST_MATCH = 0.5;
/** 移除包与爆炸包在服务端同一刻先后发出;移除先到时再等两刻收爆炸包 */
const CRYSTAL_BLAST_WAIT_MS = 100;

interface ExplosionPacket {
  x?: number; y?: number; z?: number;
  /** 1.21.11 起爆心收进 center */
  center?: { x: number; y: number; z: number };
}

export async function skillAttack(
  bot: Bot,
  target: string,
  mode: AttackMode = 'auto',
  ctx: SkillContext,
  entityId?: number,
  weaponName?: string,
): Promise<string> {
  const selectedWeapon = () => weaponName === undefined ? bestWeapon(bot)
    : meleeWeapons(bot).find(item => item.name === weaponName) ?? null;
  const requireSelectedWeapon = (): void => {
    if (weaponName === undefined) return;
    if (mode === 'ranged' || mode === 'kite') throw new SkillBlocked('attack.weapon 是近战武器；不能与 ranged/kite 混用');
    if (!inventoryReadConfirmed(bot) || (bot as Bot & {deathLifecycle?:{inventorySynced?:boolean}}).deathLifecycle?.inventorySynced === false)
      throw new SkillBlocked('当前背包尚未确认，不能核对指定武器');
    if (!selectedWeapon()) throw new SkillBlocked(`指定近战武器 ${weaponName} 不可用；没有换用其他武器或空手攻击`, [], 'local', 'resource-unavailable');
  };
  requireSelectedWeapon();
  if (!isKnownTarget(bot, target)) {
    throw new SkillBlocked(`不认识「${target}」这种目标；attack.target 要实体英文类型或玩家名，数字实体编号另填 entityId 并同时提供实际类型；未选择或攻击其他实体`);
  }
  // Auto selects usable weapons, not an implicit unarmed fallback. Recheck at execution, after any earlier
  // equip/craft/container steps. This does not disable spell programs or the cornered self-defence policy.
  if (mode === 'auto') {
    checkAbort(ctx);
    const synced = (bot as Bot & { deathLifecycle?: { inventorySynced?: boolean } }).deathLifecycle?.inventorySynced;
    if (!inventoryReadConfirmed(bot) || synced === false)
      throw new SkillBlocked('当前背包读数尚未确认，不能判定武器可用；先等服务器完整槽位，不按旧库存或空包开战');
    if (!bestWeapon(bot) && !ctx.attack.ranged?.ready(bot)) {
      const bow = bestRangedWeapon(bot);
      throw new SkillBlocked(`当前没有可选近战武器，主手为 ${bot.heldItem?.name ?? '空手'}；`
        + (bow ? `有 ${bow.name}${hasUsableArrows(bot) ? '和普通箭，但远程控制器暂不可用' : '，但没有普通箭'}` : '没有可用的弓和普通箭组合')
        + '；auto 未改为空手挥击，未开始攻击。补给后重新核对实际背包与主手；法术和避险可单独选择');
    }
  }
  const radius = attackTargetRadius(target);
  const entity = findEntity(bot, target, radius, (candidate) => candidate.isValid !== false
    && (entityId === undefined || candidate.id === entityId) && canSeeEntity(bot, candidate));
  if (!entity && entityId !== undefined) {
    throw new SkillBlocked(`当前连接 ${radius} 格内没有可见的 ${target} entityId=${entityId}；ID 失效、类型不符或被遮挡，未改打其他实体；重新观察`);
  }
  // 要打的东西不在场 = 无事可做:没打输,是没得打(见 SkillNoop)
  if (!entity) throw new SkillNoop(`附近 ${radius} 格内没看见${zhEntity(target)}，不能隔墙选它作攻击目标`);
  const selectedUuid = typeof entity.uuid === 'string' ? entity.uuid : undefined;
  const checkNamedTarget = (requireSight = false): void => {
    if (entityId === undefined) return;
    checkAbort(ctx);
    if (bot.entities[entityId] !== entity || entity.isValid === false
        || (selectedUuid !== undefined && entity.uuid !== selectedUuid)) {
      throw new SkillBlocked(`点名实体 entityId=${entityId} 已失效；未改打其他实体，重新观察`, [], 'local', 'attack-target-unconfirmed');
    }
    // Ordinary brief occlusion keeps the existing 1.5-second tracking grace.
    // Recheck sight immediately before a physical swing or bow preparation.
    if (requireSight && !canSeeEntity(bot, entity)) throw new SkillBlocked(`点名实体 entityId=${entityId} 已被遮挡；未继续攻击，重新观察`, [], 'local', 'attack-target-unconfirmed');
  };
  const ranged = ctx.attack.ranged;
  const forcedRanged = mode === 'ranged' || mode === 'kite';
  if (forcedRanged) {
    const issue = forcedRangedIssue(bot, rangedTargetOf(entity));
    if (!ranged || issue) {
      throw new SkillBlocked(`${issue ?? '远程控制器现在不可用'};${mode} 不会改用近战`);
    }
  }
  // 血线撤退只针对可能还手的目标；玩家、敌对生物及主动攻击的普通猪灵均适用。
  const attackName = entity.name ?? '';
  const dangerous = entity.type === 'player'
    || HOSTILE.has(attackName)
    // 这一步是**主动**打它:攻击本身就是挑衅,金甲带来的中立当场作废,所以 provoked 传真
    || (attackName === 'piglin' && piglinIsHostile(bot, entity, true));
  const stats = ctx.attack.acquire(entity.id);
  const deadline = Date.now() + 45_000;
  let lastSwing = 0;
  let inMelee = false;
  let strafeLeft = false;
  let strafeAt = 0;
  let weapon: HybridWeapon = forcedRanged || (mode === 'auto' && ranged?.ready(bot) && !bestWeapon(bot)) ? 'ranged' : 'melee';
  let desperate = false;
  let retreatFailed = false;
  let chaseWithoutProgress = 0;
  let rangedRetryAfter = 0;
  let outOfSightSince = 0;
  const equipMelee = async (): Promise<void> => {
    ranged?.abort();
    requireSelectedWeapon();
    const best = selectedWeapon();
    if (!best || bot.heldItem?.name === best.name) return;
    checkAbort(ctx);
    const equipDeadline = Date.now() + 3_000;
    let active = true;
    const checkEquipmentActive = (): void => {
      checkAbort(ctx);
      checkNamedTarget();
      if (!active) throw new SkillBlocked('原攻击已结束，不继续换手');
      if (stats.disconnected) throw new SkillBlocked('换手期间连接断开');
      if (!desperate && dangerous && ctx.fleeHealth() > 0 && (bot.health ?? 20) < ctx.fleeHealth()) {
        throw new SkillBlocked('换手等待期间生命低于撤退线，释放攻击任务的身体占用');
      }
      if (Date.now() >= equipDeadline) throw new SkillBlocked('换手超过3秒仍未确认，不重试库存操作');
    };
    let guard: ReturnType<typeof setInterval> | undefined;
    try {
      const interrupted = new Promise<never>((_resolve, reject) => {
        guard = setInterval(() => {
          try {
            checkEquipmentActive();
          } catch (error) { reject(error); }
        }, 50);
      });
      await Promise.race([equipHandConfirmed(bot, best, checkEquipmentActive), interrupted]);
    }
    catch (error) {
      checkAbort(ctx);
      throw new SkillBlocked(`近战武器 ${best.name} 换手失败:${String(error)};未改为空手攻击;${attackStats(stats)}`);
    }
    finally { active = false; if (guard !== undefined) clearInterval(guard); }
    checkAbort(ctx);
    if (bot.heldItem?.name !== best.name) {
      throw new SkillBlocked(`近战武器 ${best.name} 未在主手确认，实际为 ${bot.heldItem?.name ?? '空手'};未改为空手攻击;${attackStats(stats)}`);
    }
  };
  const releaseWalkOnly = walkOnlyPath(bot);
  const crystal = entity.name === 'end_crystal';
  let blasted = false;
  let onBlast: (() => void) | null = null;
  const onExplosion = (packet: ExplosionPacket): void => {
    const at = packet.center ?? packet;
    if (typeof at.x !== 'number' || typeof at.y !== 'number' || typeof at.z !== 'number') return;
    if (entity.position.distanceTo(new Vec3(at.x, at.y, at.z)) > CRYSTAL_BLAST_MATCH) return;
    blasted = true;
    onBlast?.();
  };
  if (crystal) bot._client.on('explosion', onExplosion);
  try {
    if (weapon === 'melee') await equipMelee();
    while (!stats.dead && !blasted && entity.isValid && Date.now() < deadline) {
      // 某些寻路/弓回执会立即返回；每轮让出一个游戏 tick，避免空转饿死协议 keepalive。
      await sleep(50);
      checkAbort(ctx);
      if (stats.disconnected) throw new SkillBlocked(`连接断了,主动攻击已取消;${attackStats(stats)}`);
      if (stats.dead) break;
      checkNamedTarget();
      requireSelectedWeapon();
      if (!canSeeEntity(bot, entity)) {
        outOfSightSince ||= Date.now();
        releaseMelee(bot);
        ranged?.abort();
        dropGoal(bot, 'task', '目标离开视线', ctx.diag);
        if (Date.now() - outOfSightSince >= 1_500) {
          throw new SkillBlocked(`${zhEntity(target)}离开视线，停止攻击;${attackStats(stats)}`, [], 'local', 'attack-target-unconfirmed');
        }
        continue;
      }
      outOfSightSince = 0;
      const floor = ctx.fleeHealth();
      if (!desperate && dangerous && floor > 0 && (bot.health ?? 20) < floor) {
        // 撤退是任务的一部分:走完再汇报,不能丢下一个方向就报错收工
        releaseMelee(bot);
        ranged?.abort();
        ctx.escape.active = true;
        const hp = Math.ceil(bot.health ?? 0);
        const start = bot.entity.position.clone();
        const hurtMark = stats.hurts;
        const away = bot.entity.position.minus(entity.position).normalize().scaled(24);
        const dest = bot.entity.position.plus(away);
        let pathError: string | null = null;
        await gotoGoal(bot, levelTravelGoal(dest.x, dest.z), ctx).catch((error: unknown) => {
          if (error instanceof Aborted) throw error;
          pathError = error instanceof Error ? zhErrorText(error.message) : String(error);
        });
        const p = bot.entity.position;
        const moved = p.distanceTo(start);
        const distance = entity.position.distanceTo(p);
        const hurtAgain = stats.hurts > hurtMark;
        const safe = moved >= 3 && distance >= KITE_MIN_RANGE && !hurtAgain;
        if (stats.dead || !entity.isValid) break;
        if (safe) {
          throw new SkillBlocked(
            `${stats.swings > 0 ? '打到一半' : `没跟${zhEntity(target)}动手`},生命 ${hp}/20 低于撤退线;` +
              `确认撤开 ${Math.round(moved * 10) / 10} 格,现在离目标 ${Math.round(distance * 10) / 10} 格` +
              `${pathError ? `(${pathError})` : ''};${attackStats(stats)}${underwaterOxygenNote(bot)}`,
          );
        }
        // 跑不动或撤退中还在掉血时，血线的前提已经失效；本步继续持有身体回身还手。
        desperate = true;
        retreatFailed = true;
        ctx.escape.active = false;
        weapon = forcedRanged ? 'ranged' : 'melee';
        if (weapon === 'melee') await equipMelee();
        ctx.diag?.write({
          lane: 'skill', event: 'attack-cornered', taskId: ctx.taskId,
          msg: `主动攻击撤退失败:只挪 ${Math.round(moved * 10) / 10} 格${hurtAgain ? ',仍在受击' : ''},回身还手`,
          data: { target, mode, moved, distance, hurtAgain, pathError },
        });
        continue;
      }
      const d = entity.position.distanceTo(bot.entity.position);
      const rangedReady = Date.now() >= rangedRetryAfter && Boolean(ranged?.ready(bot));
      if (!desperate && mode === 'auto' && weapon === 'ranged' && !rangedReady && !bestWeapon(bot)) {
        throw new SkillBlocked(`远程武器已不可用，且没有可切换的近战武器；未改为空手攻击;${attackStats(stats)}`);
      }
      const nextWeapon = forcedRanged
        ? 'ranged'
        : mode === 'melee' ? 'melee' : !desperate && rangedReady && !bestWeapon(bot)
          ? 'ranged' : chooseHybridWeapon(weapon, d, rangedReady);
      if (nextWeapon !== weapon) {
        weapon = nextWeapon;
        releaseMelee(bot);
        if (weapon === 'melee') await equipMelee();
      }

      if (weapon === 'ranged') {
        inMelee = false;
        dropGoal(bot, 'task', '改用远程,寻路器让位', ctx.diag);
        if (!rangedReady || !ranged) {
          if (forcedRanged) {
            throw new SkillBlocked(`${forcedRangedIssue(bot, rangedTargetOf(entity)) ?? '远程控制器现在不可用'};${mode} 不会改用近战;${attackStats(stats)}`);
          }
          weapon = 'melee';
          await equipMelee();
          continue;
        }
        if (Date.now() >= strafeAt) {
          strafeLeft = !strafeLeft;
          strafeAt = Date.now() + STRAFE_MS;
        }
        await aimAt(bot, entity);
        if (stats.dead) break;
        checkNamedTarget(true);
        pressRanged(bot, d, mode, strafeLeft);
        // Explicit kite asks for spacing first. Auto/ranged may shoot while
        // making room; the hybrid weapon preference is not a bow range limit.
        if (mode === 'kite' && d < KITE_MIN_RANGE) {
          await sleep(50);
          continue;
        }
        const result = await ranged.shoot(rangedTargetOf(entity), stats.token);
        checkAbort(ctx);
        // Count an actual release even if death arrives before its RPC settles.
        // A cancelled draw is still zero arrows; neither result proves our kill.
        if (result.kind === 'released') stats.arrows += 1;
        if (stats.dead) break;
        if (result.kind === 'released') {
          continue;
        }
        // 拉弓时目标已被移除(前一支箭打掉了水晶):交给循环后的结算
        if (result.cause === 'target_lost' && !entity.isValid) break;
        if (forcedRanged) {
          throw new SkillBlocked(`${rangedBlockedText(result)};${mode} 不会改用近战;${attackStats(stats)}`);
        }
        if (
          result.reason === 'aborted' &&
          ['bot_lost', 'lease', 'death', 'target_lost'].includes(result.cause ?? '')
        ) {
          throw new SkillBlocked(`${rangedBlockedText(result)};${attackStats(stats)}`);
        }
        // 选武器仍会选弓的距离上不改近战,射不出就受阻
        const away = entity.position.distanceTo(bot.entity.position);
        if (!bestWeapon(bot)) {
          throw new SkillBlocked(`${rangedBlockedText(result)};没有可切换的近战武器，未改为空手攻击;${attackStats(stats)}`);
        }
        if (chooseHybridWeapon('melee', away, Boolean(ranged.ready(bot))) === 'ranged') {
          throw new SkillBlocked(
            `${rangedBlockedText(result)};相距 ${Math.round(away * 10) / 10} 格,auto 在 ${HYBRID_RANGED_AT} 格外不改近战;` +
              `${attackStats(stats)}${underwaterOxygenNote(bot)}`,
          );
        }
        // 自动模式下无射线等即时失败，先尝试靠近，别在同一位置立即切回弓。
        rangedRetryAfter = Date.now() + 5_000;
        weapon = 'melee';
        await equipMelee();
        continue;
      }

      if (d > MELEE_CHASE) {
        inMelee = false;
        releaseMelee(bot);
        const before = bot.entity.position.clone();
        try {
          await gotoGoal(bot, new goals.GoalFollow(entity, 2), ctx);
        } catch (error) {
          if (error instanceof Aborted) throw error;
          const why = error instanceof Error ? zhErrorText(error.message) : String(error);
          throw new SkillBlocked(`追不上${zhEntity(target)}: ${why};${attackStats(stats)}`);
        }
        if (entity.isValid && !stats.dead && entity.position.distanceTo(bot.entity.position) > MELEE_CHASE
          && bot.entity.position.distanceTo(before) < 0.3) {
          chaseWithoutProgress++;
          if (chaseWithoutProgress >= 2) {
            throw new SkillBlocked(`追不上${zhEntity(target)}: 寻路返回了但位置没有前进;${attackStats(stats)}`);
          }
          // pathfinder 可以在空路径上立刻 resolve；让协议与战斗事件有处理时间。
          await sleep(150);
        } else {
          chaseWithoutProgress = 0;
        }
        continue;
      }
      chaseWithoutProgress = 0;
      if (!inMelee) {
        dropGoal(bot, 'task', '够得着了,自己打', ctx.diag);
        inMelee = true;
      }
      if (Date.now() >= strafeAt) {
        strafeLeft = !strafeLeft;
        strafeAt = Date.now() + STRAFE_MS;
      }
      await aimAt(bot, entity);
      if (stats.dead) break;
      pressMelee(bot, entity, dangerous ? strafeLeft : null);
      if (d <= MELEE_REACH && Date.now() - lastSwing >= attackCooldownMs(bot)) {
        if (weaponScore(bot.heldItem?.name ?? '') < 0 || weaponName !== undefined && bot.heldItem?.name !== weaponName) await equipMelee();
        await meleeSwing(bot, entity, () => {
          if (stats.dead) throw new SkillBlocked('目标已确认死亡，未继续挥击');
          checkNamedTarget(true);
          requireSelectedWeapon();
          if (weaponName !== undefined && bot.heldItem?.name !== weaponName)
            throw new SkillBlocked(`主手已不再是指定武器 ${weaponName}，未出手`);
          stats.lastSwingAt = Date.now();
          stats.lastSwingTargetId = entity.id;
          stats.swings += 1;
        });
        lastSwing = Date.now();
      } else {
        await sleep(50);
      }
    }
    if (crystal && !blasted && !entity.isValid) {
      await new Promise<void>((resolve) => {
        const timer = setTimeout(resolve, CRYSTAL_BLAST_WAIT_MS);
        onBlast = () => { clearTimeout(timer); resolve(); };
      });
    }
  } catch (error) {
    // A matching death may settle while navigation, aim or equipment is waiting.
    // Preserve that observed terminal, but never swallow cancellation or link loss.
    if (!(stats.dead && !stats.disconnected && !ctx.aborted() && error instanceof SkillBlocked)) throw error;
  } finally {
    if (crystal) bot._client.removeListener('explosion', onExplosion);
    releaseMelee(bot);
    ranged?.abort();
    ctx.escape.active = false;
    ctx.attack.release(stats);
    releaseWalkOnly();
    let targetState: AttackEvidence['targetState'] = stats.dead ? 'death-observed'
      : blasted ? 'explosion-observed' : !entity.isValid || bot.entities[entity.id] !== entity
        || (selectedUuid !== undefined && entity.uuid !== selectedUuid) ? 'untracked' : 'unknown';
    if (targetState === 'unknown' && !stats.disconnected) {
      try { targetState = canSeeEntity(bot, entity) ? 'visible' : 'occluded'; } catch { /* unknown */ }
    }
    const evidence: AttackEvidence = { schema: 'agent-mc-attack-evidence/v1', sampledAt: new Date().toISOString(),
      target: { entityId: entity.id, uuid: selectedUuid ?? null, name: entity.name ?? target }, targetState,
      deathObservedAt: typeof stats.deathObservedAt === 'number' ? new Date(stats.deathObservedAt).toISOString() : null,
      ownKillCredit: null, attempts: { meleeSwings: stats.swings, arrowsReleased: stats.arrows },
      observedHits: { melee: stats.meleeHits, ranged: stats.rangedHits }, goalVerified: false };
    try { ctx.recordObservation?.({ ...evidence }); } catch { /* A failed evidence sink never changes the native verdict. */ }
  }
  if (blasted) {
    // A nearby explosion is observed, but it does not identify who caused it.
    return `${zhEntity(target)}在原位炸了(放箭 ${stats.arrows} 支,挥击 ${stats.swings} 次)${underwaterOxygenNote(bot)}`;
  }
  if (crystal && !entity.isValid) {
    const away = Math.round(entity.position.distanceTo(bot.entity.position));
    throw new SkillBlocked(
      `${zhEntity(target)}不见了,没收到它原位的爆炸(消失时相距 ${away} 格);` +
        attackStats(stats),
    );
  }
  if (stats.dead) {
    return `确认${zhEntity(target)}死亡，未确认本人击杀归属(${attackStats(stats)})${retreatFailed ? ';撤退期间观察到目标死亡' : ''}${underwaterOxygenNote(bot)}`;
  }
  if (!entity.isValid) {
    throw new SkillBlocked(`交手中${zhEntity(target)}离开了视野,没有把“消失”算成击杀;${attackStats(stats)}${underwaterOxygenNote(bot)}`, [], 'local', 'attack-target-unconfirmed');
  }
  if (entity.isValid) {
    throw new SkillBlocked(
      `${attackStats(stats)}未确认${zhEntity(target)}死亡,超时收手${underwaterOxygenNote(bot)}`,
    );
  }
  throw new SkillBlocked(`没有确认${zhEntity(target)}死亡;${attackStats(stats)}`);
}
