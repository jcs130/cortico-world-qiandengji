/** Physically checked short moves and policy-scoped engagement candidates. */
import type { Bot } from 'mineflayer';
import { Vec3 } from 'vec3';
import type { Battlefield } from './battlefield.ts';
import type { CombatCandidate, CombatExecutionPolicy } from './combat-decision-types.ts';
import { corridorSafe } from './idle-actions.ts';
import { combatLoadout } from './combat-loadout.ts';

/** An explicitly enabled opening spell need not wait for a melee controller or a first injury.
 * The caller still checks observed ability, mana, cooldown and the authored rule. */
export function openingSpellBattlefield(field: Battlefield, cfg: CombatExecutionPolicy,
  control: { bodyFree: boolean; fight: string; enabled: boolean; fleeHealth: number }): Battlefield | null {
  if (!cfg.allowEngage || !control.enabled || control.fight === 'off' || !control.bodyFree
    || field.action.emergency || (field.self.health.current ?? 0) < control.fleeHealth + 3) return null;
  const party = new Set([field.self.entityId, ...field.actors.filter(e => e.relation === 'ally'
    && e.health.current !== 0 && e.entityId !== null).map(e => e.entityId!)]);
  return { ...field, actors: field.actors.filter(e => e.relation !== 'hostile'
    || e.health.current !== 0 && e.lineOfSight === true && e.distance !== null
      && (cfg.engageScope === 'hostile' || e.relationSource === 'server'
        && e.targetEntityId !== null && party.has(e.targetEntityId))) };
}

export function combatReactions(bot: Bot, field: Battlefield, cfg: CombatExecutionPolicy,
  control: { bodyFree: boolean; canStep: boolean; targetId: number | null; sinceHitMs: number | null;
    fight: string; fleeHealth: number; chaseMax: number; trackingTargets?: ReadonlySet<number>;
    engagementTargets?: ReadonlySet<number>;
    retreatAvailable?: boolean }, programmable = false): CombatCandidate[] {
  if (field.action.emergency) return [];
  const hostiles = field.actors.filter(e => e.relation === 'hostile' && e.health.current !== 0
    && e.entityId !== null && e.lineOfSight === true && e.distance !== null);
  const partyIds = new Set([field.self.entityId, ...field.actors.filter(e => e.relation === 'ally'
    && e.health.current !== 0 && e.entityId !== null).map(e => e.entityId!)]);
  const target = hostiles.find(e => e.entityId === control.targetId) ?? hostiles[0];
  if (!target) return [];
  if (field.action.tracking && !control.bodyFree) return []; // A newly queued task must not wait behind renewed tracking leases.
  const candidates: CombatCandidate[] = [];
  // Spacing/withdrawal are useful BEFORE the first hit, including while the planner thinks.
  if (cfg.allowMovement && (control.bodyFree || field.action.fighting || field.action.tracking)) {
    if (control.retreatAvailable !== false)
      candidates.push({ id: 'retreat', kind: 'retreat', intent: 'Withdraw without attacking; continue through the body controller.' });
    const trackable = hostiles.filter(e => !control.trackingTargets || control.trackingTargets.has(e.entityId!));
    const tracked = trackable.find(e => e.entityId === control.targetId) ?? trackable[0];
    // Watching is an explicit authored primitive, not a default combat choice.
    if (programmable && tracked?.position && tracked.distance! <= control.chaseMax + 4)
      candidates.push({ id: `track_${tracked.entityId}`, kind: 'track', targetId: tracked.entityId!, uuid: tracked.uuid,
        minDistance: 5, maxDistance: 8, leaseMs: 4000,
        intent: `${field.action.fighting ? 'Stop current attacks and watch' : field.action.tracking ? 'Continue watching' : 'Watch'} visible hostile ${tracked.type ?? 'entity'} at 5-8 blocks for up to 4 seconds without attacking; stop on lost sight or unsafe ground.` });
  }
  if (cfg.allowEngage && (control.bodyFree || field.action.fighting) && control.fight !== 'off'
    && combatLoadout(bot).canEngage === true
    && (field.self.health.current ?? 0) >= control.fleeHealth + 3) {
    // The native controller owns admission. Its existing pursuit pool includes
    // a four-block retention band; do not hide those targets behind a second,
    // narrower acquisition test (or a different 3D-vs-horizontal distance).
    const enemies = hostiles.filter(e => (control.engagementTargets
      ? control.engagementTargets.has(e.entityId!)
      : e.position !== null && Math.hypot(e.position[0] - field.self.position[0],
        e.position[2] - field.self.position[2]) <= control.chaseMax + 4)
      && (cfg.engageScope === 'hostile' || (e.relationSource === 'server'
        && e.targetEntityId !== null && partyIds.has(e.targetEntityId))));
    for (const enemy of enemies.filter(e => e.entityId !== control.targetId || !field.action.fighting))
      candidates.push({ id: `engage_${enemy.entityId}`, kind: 'engage', targetId: enemy.entityId!, uuid: enemy.uuid,
        intent: `Attack visible hostile ${enemy.type ?? 'entity'} at ${enemy.distance} blocks now, before it hits us; approach and continue attacking through the body controller, resuming paused work afterwards.` });
  }
  if (!cfg.allowMovement || !field.action.fighting || !control.canStep || target.position === null
    || (!programmable && (control.sinceHitMs ?? 0) < cfg.movementStallMs)) return candidates;
  const p = bot.entity.position, [x, , z] = target.position;
  const dx = x - p.x, dz = z - p.z, len = Math.hypot(dx, dz);
  if (len < 0.01) return candidates;
  const dirs = programmable ? Array.from({ length: 8 }, (_, i) => ({ x: Math.cos(i * Math.PI / 4),
    z: Math.sin(i * Math.PI / 4), id: `direction_${i}`, intent: 'Take a collision-checked short step while continuing the current attack.' })) : target.distance! > 4
    ? [{ x: dx / len, z: dz / len, id: 'approach', intent: 'Take a verified short step toward the visible enemy to get into attack range.' },
      { x: -dz / len, z: dx / len, id: 'side', intent: 'Take a verified short side step to change the approach angle, continuing attacks.' }]
    : [{ x: -dz / len, z: dx / len, id: 'side', intent: 'Take a verified short side step around the enemy, continuing attacks.' },
      { x: -dx / len, z: -dz / len, id: 'back', intent: 'Take a verified short step away from the enemy to gain space, continuing attacks.' }];
  for (const d of dirs) {
    const to = new Vec3(p.x + d.x * 1.2, p.y, p.z + d.z * 1.2);
    if (corridorSafe(bot, p, to)) candidates.push({ id: `step_${d.id}`, kind: 'step',
      intent: d.intent, destination: [to.x, to.y, to.z] });
  }
  return candidates;
}
