# 千灯纪适配与资料包

服务器扩展通过 peerDependencies 使用宿主提供的同一份共享核心，不自行安装另一份。查询契约候选需要 `agent-mc-world@0.5.7-rc.149-preview.1` 或兼容版本，宿主应显式依赖满足范围的核心。游戏登录机制由核心实现，服务端确认后才放行操作；本包的可选网站接入模块保存独立的私有身份，不复制游戏认证状态机。可选 MineDojo 资料索引默认路径为空，不自动下载或启用。

只读查询声明由核心的 `serverQueryTool` 生成，同时接入实际引擎代理和离线工具目录。必填参数、数量和格式约束，以及查询发送与回执读取的分离形式，在压缩工具目录中保留。格式正确不证明某个 ID 已存在或已观测，副本、职业与技能 ID 仍须来自实际服务端记录；本包不会代替 Agent 猜测、自动补发或把受理状态当成目标完成。

`agent-mc-qiandengji` 是可选服务器扩展，不是 World 插件。它依赖中立 `agent-mc-world` 核心，不依赖或加载 Cortico。DSH 和其他宿主可以显式创建 `MymcAgentRuntime`，人格、目标、主模型和长期记忆仍由自己的宿主管理。

默认导出具名端口：`MymcAgentRuntime`、`MymcWorld`、配置与校验、资料目录、`QIANDENGJI_PACK`。`/host-decisions` 提供显式宿主快决策服务。启用前配置服务地址；不配置时没有额外模型请求。

保留宿主原身体时，可显式组合公开的 `createQiandengjiCastTool`：提供本人现有已认证连接的发送端口、当前 `CombatSpells` 观察账、`ObservedCommandCatalog` 及认证/倒地门禁。工厂复用中立 Engine 的同一 `mc_cast` 实现，不创建连接、不接管移动或任务队列、不自动施法。可信系统回执和经校验的 `parseSkillsPayload` 用于更新当前观察；断线/换连接应重置状态。`已发送` 与实际生效、目标完成分别核验；传输异常保持未知，不自动重试。宿主可经核心的 `createServerToolRouter` 注册工具，需保留自己的调用身份、取消和防重放机制。这里只提供显式单次施放，不宣称接入了自动组合控制器。

若宿主已接收原生 `MC_RPG` 技能入口，传入 `skillDetail: id => nativeRpg.skillDetail(id)`，沿用经校验且绑定本连接的 `NativeRpgState`。共享施法端口会保留专用命令入口的诊断，不把菜单/传送等命令当成 `/mycli cast`，不拼接被拒的原施法参数，也不替 Agent 自动执行；断线或职业变更后由原状态对象清除这些观测。`ChatPolicyState` 在默认入口及 `/engine` 均公开导出，供不同宿主复用真实聊天范围证据。

`agent-mc-qiandengji/portal` 导出 `QiandengjiPortalAccess`，供 SDK、MCP 宿主及其他框架复用[官方网站接入](https://mc.kangqiang.site/agent-api.html)。显式传入本机私有目录，使用 `prepare` 准备邀请身份、`status` 查询原请求；`connectionSettings` 再次核对 `ready` 与建号成功后才返回连接参数和私有密码字段指针。`state` 只读本地状态，不产生网络或模型请求。已有网站身份使用 `importIdentity` 续用；普通游戏角色保持原连接，不用邀请重建。此模块不自动连接游戏，不提供后台轮询或额外模型循环。

普通 `goto` 默认保持步行。确认服务器支持并需要自动改道时，显式配置 `serverTravel.enabled: true`，才会在匹配目的地前加入服务器传送。Agent 主动请求的传送命令不受此开关限制。升级后不再把附近取物自动改成传送。

原文资料在 `dist/guides/`，协议与动作校验在 `dist/engine/`。`/manifest` 声明资料包版本与能力。资料用于按需查询，实时库存、魔力、保护和任务结果以本人连接的回执为准。

构建来源为本仓库独立维护的 `integrations/qiandengji/`。Cortico 专用注册入口和控制台客户端不进入本包；历史许可证和来源说明保留。

`agent-mc-qiandengji/presentation` 是可独立使用的被动观战端口，唯一输入是调用方已拥有的 Mineflayer bot。自动模式先核验本连接直接收到的 `MC_GUIDE` 身份、会话和时间，再注册千灯纪状态通道；普通服务器不注册这些通道。它只投影本人生命、技能和魔力，离线、死亡、换身份或过期即清除；不登录、不发送游戏命令、不创建模型回路或第二条游戏连接。服务器专用解析只维护在本资料包，通用核心仅装配显式的本地端口。发布者也可按提交与 SHA256 把此无依赖文件作为静态扩展资料交付，不必安装任何宿主适配器。
