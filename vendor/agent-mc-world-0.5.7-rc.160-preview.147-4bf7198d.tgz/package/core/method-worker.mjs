import { parentPort, workerData } from 'node:worker_threads';
import 'ses';
import { Vec3 } from 'vec3';
import { procedureProgram } from './support/procedure-program.mjs';
import { GoalBlock, GoalNear } from './method-goals.mjs';

lockdown({ errorTaming: 'unsafe', consoleTaming: 'safe' });

let serial = 0;
const pending = new Map();
const rpc = harden((method, args = {}, scope) => {
  const result = new Promise((resolve, reject) => {
    const id = ++serial;
    pending.set(id, { resolve, reject, method });
    parentPort.postMessage({ kind: 'call', id, method, args: JSON.parse(JSON.stringify(args)), scope });
  });
  const name = method === 'mineflayer' ? `bot.${args.name}` : `mc.${method}`;
  return new Proxy(result, {
    get(target, key) {
      if (key === 'then' || key === 'catch' || key === 'finally') return target[key].bind(target);
      if (key === Symbol.toStringTag) return Reflect.get(target, key);
      throw new TypeError(`${name}() returns a Promise; await it before reading ${String(key)}. No observation was read from this Promise.`);
    },
  });
});
parentPort.on('message', (message) => {
  const request = pending.get(message.id);
  if (!request) return;
  pending.delete(message.id);
  if (message.error) request.reject(new Error(message.error));
  else request.resolve(harden(request.method === 'mineflayer' ? revive(message.value.value) : message.value));
});

function revive(value) {
  if (Array.isArray(value)) return value.map(revive);
  if (!value || typeof value !== 'object') return value;
  if (Object.keys(value).length === 3 && ['x', 'y', 'z'].every(key => typeof value[key] === 'number')) {
    return new Vec3(value.x, value.y, value.z);
  }
  const result = Object.fromEntries(Object.entries(value).map(([key, child]) => [key, revive(child)]));
  if (value.properties && value.stateId !== undefined && value.position) result.getProperties = () => result.properties;
  if (value.sign && value.stateId !== undefined && value.position) result.getSignText = () => [result.sign.front, result.sign.back];
  return result;
}

function capabilities(scope) {
  const bot = workerData.nativeMethods ? Object.fromEntries(workerData.nativeMethods
    .filter(name => !name.includes('.')).map(name => [name, (...args) => rpc('mineflayer', { name, args }, scope)])) : undefined;
  if (bot) bot.inventory = { items: () => rpc('mineflayer', { name: 'inventory.items', args: [] }, scope) };
  if(bot&&workerData.nativeMethods.includes('pathfinder.goto')) bot.pathfinder={goto:goal=>rpc('mineflayer',{name:'pathfinder.goto',args:[goal]},scope)};
  if (bot) for (const key of ['entity', 'entities', 'players']) Object.defineProperty(bot, key, {
    get() { throw new TypeError(`bot.${key} is not a live object in this worker. Use await bot.read("${key}") or await bot.read("entitySnapshot") for a detached, read-only observation.`); },
    enumerable: false,
  });
  return { mc: harden({ capabilities: () => rpc('capabilities', {}, scope), state: () => rpc('state', {}, scope), do: (steps, options) => {
      if(options!==undefined&&(!options||typeof options!=='object'||Array.isArray(options)||Object.keys(options).some(k=>k!=='queue')
        || !['append','now','afterCheckpoint'].includes(options.queue)))throw new TypeError('mc.do options must be {queue:"append"|"now"|"afterCheckpoint"}');
      return rpc('do', { steps, ...(options===undefined?{}:{queue:options.queue}) }, scope);
    },
    flightPlan: args => rpc('flightPlan', args, scope), swimPlan: args => rpc('swimPlan', args, scope) }), ...(bot ? { bot: harden(bot), Vec3: harden(Vec3),goals:harden({GoalBlock,GoalNear}) } : {}) };
}

try {
  let result;
  if (workerData.graph) {
    const program = procedureProgram(workerData.graph, { capabilities, maxInvocations: workerData.maxInvocations,
      onInvocation: event => parentPort.postMessage({ kind: 'procedure', ...event }) });
    result = workerData.validate ? program.validate() : await program.run(workerData.params);
  } else {
    const compartment = new Compartment({ ...capabilities(), params: harden(workerData.params) });
    const program = compartment.evaluate(`(async () => {\n${workerData.code}\n})`);
    if (typeof program !== 'function') throw new Error('code必须是异步函数体');
    result = workerData.validate ? { valid: true } : await program();
  }
  if (workerData.validate) result = { ...result, scope: 'syntax-only', executed: false };
  parentPort.postMessage({ kind: 'done', value: result === undefined ? null : result });
} catch (error) {
  parentPort.postMessage({ kind: 'error', error: String(error).slice(0, 1600) });
}
