/** Package-owned game/host ports, structurally compatible with Cortico API 5.
 * The standalone SDK requires no Cortico package, including its types.
 */
import type { CallControl, ExecutionReceipt } from './protocol.ts';
export * from './protocol.ts';
export type EventOrigin = 'external' | 'internal';
export type EventTag = 'snapshot' | 'speak';
export type TriggerMode = 'preempt' | 'interrupt' | 'flush' | 'debounce' | 'piggyback';
export interface PushOptions { deliver?: boolean; trigger?: TriggerMode }
export interface BlobRef { handle: string; mime: string; name?: string; fallbackText: string }
export type BlobInput = { bytes: Uint8Array; mime: string; name?: string; fallbackText: string }
  | { handle: string; fallbackText: string };
export interface EventEnvelope {
  protocol?: import('./protocol.ts').ProtocolVersion;
  cursor: number; run?: string; type: string; ts: string; source: string; origin: EventOrigin;
  text: string; senderKey?: string; tags?: readonly EventTag[]; meta?: Record<string, unknown>;
  contextDelivery?: 'deliver' | 'archive-only'; trigger?: TriggerMode; blobs?: BlobRef[]; ephemeral?: true;
  execution?: ExecutionReceipt;
}
export type DeferredRendered = string | { text: string; blobs?: BlobInput[] };
export interface DeferredEventSpec {
  type: string; source: string; origin: EventOrigin; senderKey?: string;
  meta?: Record<string, unknown>; tags?: readonly EventTag[];
  render(signal?: AbortSignal): DeferredRendered | null | Promise<DeferredRendered | null>;
}
export interface EventRangeQuery {
  fromCursor?: number; toCursor?: number; fromTs?: string; toTs?: string;
  senderKey?: string; source?: string; origin?: EventOrigin; limit?: number;
}
export interface EventGrepQuery extends Omit<EventRangeQuery, 'fromCursor' | 'toCursor'> { keyword: string; context: number }
export interface EventStoreReader {
  get(cursor: number): EventEnvelope | undefined;
  latestCursor(): number;
  range(query: EventRangeQuery): EventEnvelope[];
  around(cursor: number, before: number, after: number): EventEnvelope[];
  grep(query: EventGrepQuery): Array<{ hitCursor: number; events: EventEnvelope[] }>;
}
export type ToolTag = 'read' | 'write' | 'speak' | 'act' | 'flow' | 'snapshot';
export interface ToolSchema { name: string; description: string; parameters: Record<string, unknown> }
export interface ToolCallContext {
  role: string; log: Logger; callId?: string; turnId?: string; round?: number; signal?: AbortSignal;
  /** Actual host-selected decision provenance, independent of the agent name/role. */
  attribution?: import('../../core/operation-experience.ts').OperationAttribution;
  queueExternalEvents?: (events: EventEnvelope[]) => void;
}
export interface ToolOutcome {
  text: string; blobs?: BlobInput[]; failed?: true; endsTurn?: boolean; retryAfterMs?: number; meta?: Record<string, unknown>;
  execution?: ExecutionReceipt; events?: EventEnvelope[]; control?: CallControl;
  /** Structured query data or diagnostics; task lifecycle remains separate. */
  data?: Record<string, unknown>;
}
export interface ToolDef extends ToolSchema {
  tags: readonly ToolTag[]; barrierAfter?: boolean; endsTurn?: boolean; interruptible?: boolean;
  /** Resource requirement, not a read-only or authorization claim. Independent
   * tools may have side effects but never acquire/mutate the physical body.
   * Absent/unknown metadata retains conservative legacy scheduling. */
  bodyControl?: 'independent' | 'exclusive';
  /** Describes a tool contract, without executing it. Hosts may route detailed execution help to an executor. */
  helpFor?(args: Record<string, unknown>): string | null;
  /** Pure host hint; never invokes a model or dispatches/rewrites work. */
  familiarAction?(args: Record<string, unknown>): FamiliarAction | null;
  /** True only for a branch that cannot acquire/mutate the game body. */
  readOnlyCall?(args: Record<string, unknown>): boolean;
  /** Explicit background learning branch: may edit versioned methods/parameters or run isolated practice,
   * but cannot acquire the live body, dispatch game actions, or change engine/host files.
   * This is not a read claim. Hosts still persist attribution and apply normal validation. */
  learningCall?(args: Record<string, unknown>): boolean;
  /** Optional protocol-owned activity subjects for a call; never inferred by a host from prose. */
  workSubjects?(args: Record<string, unknown>): readonly string[];
  /** Current backend capability, independent of the existence of the public tool schema. */
  runtimeAvailable?(): boolean;
  handler(args: Record<string, unknown>, context: ToolCallContext): Promise<string | ToolOutcome>;
}
export interface FamiliarAction {
  steps: Record<string, unknown>[]; command: Record<string, unknown>; label: string; condition: string;
}
export interface LLMUsage {
  promptTokens: number; completionTokens: number; cacheHitTokens: number; cacheMissTokens: number; reasoningTokens?: number;
}
export interface ModelFacts { model(): string; accepts(mime: string): boolean; contextWindow(): number | undefined }
export interface WorldHost {
  pushEvent(event: Omit<EventEnvelope, 'cursor' | 'origin' | 'contextDelivery' | 'blobs'> & {
    origin?: EventOrigin; blobs?: BlobInput[] }, options?: PushOptions): Promise<EventEnvelope>;
  pushDeferred(event: Pick<DeferredEventSpec, 'type' | 'senderKey' | 'meta' | 'tags' | 'render'> & {
    origin?: EventOrigin }, options?: { trigger?: TriggerMode }): void;
  store: EventStoreReader;
  drainPendingEvents(filter: (event: EventEnvelope) => boolean): Promise<EventEnvelope[]>;
  modelFacts: ModelFacts;
  decisions?: import('./decision.ts').DecisionPort;
  recallGameLessons?(query:string): {reference:string;summary:string;content:string;truncated:boolean;trust:string;currentWorldVerified:boolean}[];
  blob(handle: string): { bytes: Uint8Array; mime: string } | null;
  reportUsage(usage: LLMUsage, options?: { model?: string; label?: string }): void;
  llmStalls?(withinMs: number): Promise<number>;
  log: Logger;
}
export interface WorldRequestFacts {
  /** Native world identity, separate from the dimension type; absent on legacy producers. */
  world?: import('./world-scope.ts').WorldIdentityObservation;
  /** Event state streams fully represented by these current facts. This permits
   * request-only replacement of old state snapshots, not deletion of the event
   * ledger, terminal outcomes or evidence of historical progress. */
  text: string; snapshotTypes: readonly string[]; parts?: readonly import('./protocol.ts').FactPart[];
  /** Stable selectable partition keys. A declared key absent from parts has no
   * current observation; hosts must not restore a previous value or infer success. */
  partKeys?: readonly string[];
  /** Producer-declared semantic dependencies, not a host's activity policy.
   * Selecting a partition includes its dependencies even after a profile override.
   * Missing dependency observations remain explicitly unknown. */
  partDependencies?: Readonly<Record<string, readonly string[]>>;
  /** Opaque critical body lifecycle identity. Changes on death, reconnect or
   * teleport, not ordinary walking, hunger or health ticks. Not permission to
   * cancel/replay an already accepted action. */
  decisionBoundary?: string;
  /** Producer-owned current identity, body queue and execution results required by an active body owner. */
  executionPartKeys?: readonly string[];
  /** Optional typed server work lifecycle. Host-owned intentions require explicit matching references. */
  workStates?: readonly import('./work-state.ts').WorkState[];
  /** Observed activity attribution. Absence of a revision does not imply completion evidence. */
  workBindings?: readonly import('./work-state.ts').WorkBinding[];
  /** Bounded current capability discovery; not execution eligibility or a model-selected plan. */
  options?: import('./options.ts').MinecraftOptionsSnapshot;
  /** World-owned compact current facts for optional fast classification; complete evidence remains in text/parts. */
  decision?: { sampledAtMs: number; state: Readonly<Record<string, unknown>> };
  experience?: { scope: import('../../core/game-memory.ts').GameMemoryScope; observation: import('../../core/operation-experience.ts').OperationObservation | null };
  /** Fresh typed fields for optional host-side bounded decision stability checks. */
  decisionStability?: { sampledAtMs: number; identity: unknown; dimension: string | null;
    position: readonly [number, number, number] | null; health: number | null; food: number | null;
    guards: Readonly<Record<string, unknown>>;
    /** Producer-owned current navigation identity, not permission to interrupt or execute a route. */
    route?: { generation: number; positionEpoch: number; speedBlocksPerSec: number;
      policy: import('../../core/journey.ts').JourneyChoicePolicy; risks: readonly string[];
      task: { id: number; stepIndex: number; stepCount: number; step: string; skill: string;
        resumable: boolean; destination: readonly number[]; dimension: string } | null;
      waiting: readonly { id: number; label: string }[]; hold: string | null; goalOwner: string | null;
      fighting: boolean; environment: string | null; windowOpen: boolean; cursorOccupied: boolean;
      footing: { kind: string; block: string | null; grounded: boolean | null } | null;
      entities: readonly { id:number|null;name:string;kind:string;visible:boolean|null;position:readonly[number,number,number]|null;
        health:number|null;note:string|null;item:unknown }[];
      journeyId: string | null;
      /** Progress notices intentionally contain no landmark cues. Absent on older producers. */
      journeyReason?: 'cue' | 'progress' | null;
      journeyCues: readonly { position: readonly [number,number,number]; observedAtMs:number }[] } };
}
export interface StoragePart {
  key: string; label: string; kind: 'disk' | 'memory'; location?: string; danger?: boolean; note?: string; order?: number;
  stat(): string; clear(): Promise<string> | string;
}
export interface WorldPanelDecl { id: string; title: string; description?: string; getMethods?: readonly string[] }
export interface PromptDocDecl {
  key: string; title: string; description: string; path: string; deploymentPath?: string; role?: 'envPrompt' | 'prefix';
  vars?: Array<{ name: string; description: string; multiline?: boolean }>;
}
export interface ConfigProperty {
  type: 'integer' | 'number' | 'boolean' | 'string' | 'array' | 'object'; title: string; description?: string;
  minimum?: number; maximum?: number; multipleOf?: number; enum?: string[];
  items?: { type: 'integer' | 'number'; minimum?: number; maximum?: number };
  minItems?: number; maxItems?: number; nullable?: boolean;
  'x-scale'?: number; 'x-suffix'?: string; 'x-hot'?: boolean; 'x-options'?: string;
  'x-path'?: { kind: 'file' | 'directory'; extensions?: string[]; recommendedDir?: string };
  'x-download'?: { href: string; label?: string };
}
export interface ConfigGroup {
  id: string; owner: 'core' | 'persona' | `world:${string}` | `provider:${string}`;
  schema: { type: 'object'; title: string; description?: string; properties: Record<string, ConfigProperty> };
}
export interface WorldConsoleDecl {
  /** Optional metadata facet preserved by wrappers; contains no authentication state. */
  connection?: { ready: boolean; phase: string } | null;
  label?: string;
  lamps?: Array<{ label: string; state: 'online' | 'loading' | 'error' | 'offline'; hint?: string }>;
  badges?: Array<{ label: string; value: string | number; tone?: 'on' | 'off' | 'plain' }>;
  panels?: WorldPanelDecl[];
  invoke?(panel: string, method: string, args: unknown[]): Promise<unknown>;
  promptDocs?: PromptDocDecl[]; storage?: StoragePart[];
  links?: Array<{ label: string; href: string; inheritTheme?: boolean }>; config?: ConfigGroup[];
}
/** Execution environment port; callers can supply an alternative implementation. */
export interface World {
  /** Backend body guide; absent worlds keep the existing client instructions. */
  environment?(): string;
  id: string;
  envPromptVars(): Record<string, string> | null | Promise<Record<string, string> | null>;
  tools(): ToolDef[];
  console?(): WorldConsoleDecl;
  start(host: WorldHost): Promise<void>;
  stop(): Promise<void>;
  onTurnEnded?(): void | Promise<void>;
}
export type LogLevel = 'trace' | 'debug' | 'info' | 'warn' | 'error';
export interface LogAnchorFields { sess?: string; round?: number; resp?: string; call?: string; ev?: number; task?: number }
export interface LogEmitOptions extends LogAnchorFields { event?: string; durMs?: number; data?: unknown; err?: unknown; ts?: string }
export interface LogError { name: string; message: string; stack?: string }
export interface Logger {
  trace(msg: string, data?: unknown): void; debug(msg: string, data?: unknown): void;
  info(msg: string, data?: unknown): void; warn(msg: string, data?: unknown): void; error(msg: string, data?: unknown): void;
  emit(level: LogLevel, msg: string, options?: LogEmitOptions): void;
  child(area: string): Logger;
}
